(function(){
var I180="icon-180.png",I192="icon-192.png";
var h=document.head;
function add(tag,attrs){var e=document.createElement(tag);for(var k in attrs)e.setAttribute(k,attrs[k]);h.appendChild(e);return e;}
document.title='숭이 건강기록';
add('meta',{name:'apple-mobile-web-app-capable',content:'yes'});
add('meta',{name:'mobile-web-app-capable',content:'yes'});
add('meta',{name:'apple-mobile-web-app-title',content:'숭이'});
add('meta',{name:'apple-mobile-web-app-status-bar-style',content:'default'});
add('meta',{name:'theme-color',content:'#FFF6EF'});
add('link',{rel:'apple-touch-icon',href:I180});
add('link',{rel:'icon',type:'image/png',href:I192});
var v=document.querySelector('meta[name=viewport]');if(v&&v.content.indexOf('viewport-fit')<0)v.content+=', viewport-fit=cover';
})();
