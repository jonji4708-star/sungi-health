window.__DC_LOGIC_FACTORY=function(DCLogic,StreamableLogic,React){

const HOSP = { S: '서울동물심장병원', J: '지중해동물병원', B: '비엔동물전문의료센터', P: '부평종합동물의료센터' };
const HOSP_HUE = { S: 155, J: 75, B: 300, P: 220 };
const DMAP = { '03-20':'S','03-24':'J','04-03':'S','04-08':'J','04-10':'S','04-25':'B','04-26':'B','04-27':'B','04-28':'P','05-02':'S','05-04':'B','05-05':'B','05-06':'P','05-07':'P' };
let T0 = Date.UTC(2026,2,14), T1 = Date.UTC(2026,10,10);
const toT = d => { const [m, dd] = d.split('-').map(Number); return Date.UTC(2026, m-1, dd); };
const P = s => s.trim().split(/\s+/).map(tok => { const [d, v, h] = tok.split('|'); return { d, v: +v, h: h || DMAP[d] || 'P' }; });
const CBC_D = '03-20 03-24 04-03 04-08 04-10 05-02 05-05|P 07-02 07-22 08-12 09-02 09-30 10-09 10-21 10-28 11-04'.split(' ');
const cbc = vals => P(CBC_D.map((d,i)=> { const [dd,h]=d.split('|'); return dd+'|'+vals[i]+(h?'|'+h:''); }).join(' '));

const BASE_DATA = [
  { title: '신장', sub: 'BUN · 크레아티닌 · 인 · SDMA', items: [
    { name: '크레아티닌', abbr: 'CREA', unit: 'mg/dL', lo: 0.4, hi: 1.4, pts: P('03-20|1.92 03-24|2.0 04-03|1.86 04-08|2.2 04-10|2.04 04-25|2.35 04-26|2.47 04-27|2.74 04-28|2.64 05-02|2.22 05-04|2.28 05-05|2.61 05-12|2.02 06-12|2.39 06-18|2.16 07-02|1.98 07-22|2.03 08-12|1.85 08-29|1.46 09-02|1.62 09-09|1.54 09-16|1.42 09-30|1.47 10-09|1.45 10-21|1.81 10-28|2.91 11-04|1.77') },
    { name: '혈중요소질소', abbr: 'BUN', unit: 'mg/dL', lo: 9.2, hi: 29.2, pts: P('03-20|40.8 03-24|37 04-03|42.4 04-08|48 04-10|46.2 04-25|62.9 04-26|64.1 04-27|76.6 04-28|71.1 05-02|49.4 05-04|58.1 05-05|68.2 05-12|66.1 06-12|137.1 06-18|85 07-02|57.8 07-22|65.8 08-12|56.4 08-29|52.4 09-02|58.4 09-09|66.4 09-16|53.9 09-30|49.2 10-09|53.8 10-21|66.2 10-28|138.3 11-04|63.6') },
    { name: '인', abbr: 'PHOS', unit: 'mg/dL', lo: 1.9, hi: 5.0, pts: P('03-20|4.4 03-24|6.1 04-03|5.6 04-10|5.5 04-25|8.5 04-26|10.9 04-27|12.6 04-28|7.9 05-02|7.3 05-04|9.6 05-05|12 05-12|5.2 06-12|7.2 06-18|6.8 07-02|6.4 07-22|8.5 08-12|5.9 08-29|6.7 09-02|6.4 09-09|7.3 09-16|7.9 09-30|7.0 10-09|8.1 10-21|10.2 10-28|10 11-04|7.7') },
    { name: 'SDMA', abbr: 'SDMA', unit: 'μg/dL', lo: 0, hi: 14, pts: P('03-20|24 03-24|24 04-03|24 04-08|25 04-10|31') },
  ]},
  { title: '전해질', sub: '나트륨 · 칼륨 · 염소', items: [
    { name: '나트륨', abbr: 'Na⁺', unit: 'mmol/L', lo: 144, hi: 160, pts: P('03-20|131 03-24|141 04-03|138 04-08|142 04-10|137 04-25|135 04-26|141 04-27|149 04-28|142 05-02|130 05-04|130 05-05|135 05-06|151 05-12|135 06-12|141 06-18|140 07-02|140 07-22|139 08-12|132 08-29|128 09-02|126 09-09|132 09-16|130 09-30|128 10-09|131 10-21|133 10-28|136 11-04|138') },
    { name: '칼륨', abbr: 'K⁺', unit: 'mmol/L', lo: 3.5, hi: 5.8, pts: P('03-20|4.3 03-24|4.5 04-03|4.2 04-08|4.8 04-10|4.5 04-25|4.6 04-26|4.8 04-27|5.3 04-28|5.59 05-02|5.5 05-04|4.8 05-05|5.2 05-06|3.47 05-12|5.23 06-12|5.06 06-18|5.46 07-02|5.37 07-22|4.93 08-12|4.9 08-29|4.53 09-02|5.32 09-09|5.3 09-16|5.07 09-30|4.79 10-09|5.02 10-21|5.26 10-28|5.44 11-04|5.56') },
    { name: '염소', abbr: 'Cl⁻', unit: 'mmol/L', lo: 109, hi: 122, pts: P('03-20|87 03-24|97 04-03|97 04-08|101 04-10|97 04-25|97 04-26|109 04-27|113 04-28|108 05-02|85 05-04|89 05-05|92 05-06|112 05-12|95 06-12|108 06-18|100 07-02|98 07-22|99 08-12|94 08-29|97 09-02|94 09-09|100 09-16|102 09-30|108 10-09|108 10-21|109 10-28|111 11-04|121') },
  ]},
  { title: '혈구 (CBC)', sub: '빈혈 · 백혈구 · 혈소판', items: [
    { name: '적혈구 용적', abbr: 'HCT', unit: '%', lo: 37.3, hi: 61.7, pts: cbc([21.5,22.2,21.1,30.4,27.2,41.4,41.7,23.5,37.1,42.0,29.2,27.9,26.2,22.9,25.4,22.1]) },
    { name: '혈색소', abbr: 'HGB', unit: 'g/dL', lo: 13.1, hi: 20.5, pts: cbc([9.8,7.9,8.3,10.3,10.2,15.5,16.2,9.1,13.1,15.3,11.1,10.9,10.1,8.9,9.4,8]) },
    { name: '망상적혈구', abbr: 'RETIC', unit: 'K/μL', lo: 10, hi: 110, pts: cbc([106.5,265.2,132,232.7,145.2,107.1,56.6,168.5,341.4,18.6,21.0,110.0,28.8,79.0,94.9,128.7]) },
    { name: '평균 적혈구 용적', abbr: 'MCV', unit: 'fL', lo: 61.6, hi: 73.5, pts: cbc([53.1,55.5,56,57.4,57.1,52.2,50.1,47.3,54.0,52.0,48.6,45.7,45.5,45.5,49.2,49.1]) },
    { name: '백혈구', abbr: 'WBC', unit: '10⁹/L', lo: 5.05, hi: 16.76, pts: cbc([10.78,10.03,10.52,14.38,13.66,14.06,22.64,12.22,13.04,14.57,15.31,15.32,14.91,15.51,15.86,14.83]) },
    { name: '호중구', abbr: 'NEU', unit: 'K/μL', lo: 2.95, hi: 11.64, pts: cbc([9.1,8.15,8.79,12.29,11.92,12.45,20.96,9.80,11.04,11.99,13.45,13.59,12.95,13.73,13.43,13]) },
    { name: '혈소판', abbr: 'PLT', unit: 'K/μL', lo: 148, hi: 484, pts: cbc([748,688,446,647,608,638,693,771,475,678,632,822,950,874,892,610]) },
  ]},
  { title: '간 · 염증 · 단백', sub: 'ALKP · ALT · AST · GGT · 빌리루빈 · CRP · 알부민', items: [
    { name: '알칼리성 인산분해효소', abbr: 'ALKP', unit: 'U/L', lo: 47, hi: 254, pts: P('04-03|982 04-10|976 05-02|1183 09-30|1018 10-09|861 10-21|972 11-04|1048') },
    { name: '간수치', abbr: 'ALT', unit: 'U/L', lo: 17, hi: 78, pts: P('03-20|88 03-24|65 04-03|75 04-10|70 05-02|73 09-30|43 10-21|51 11-04|73') },
    { name: '아스파르테이트 아미노전이효소', abbr: 'AST', unit: 'U/L', lo: 0, hi: 50, pts: [] },
    { name: '감마글루타밀전이효소', abbr: 'GGT', unit: 'U/L', lo: 0, hi: 11, pts: [] },
    { name: '총 빌리루빈', abbr: 'TBIL', unit: 'mg/dL', lo: 0, hi: 0.9, pts: [] },
    { name: 'C-반응성 단백 (염증)', abbr: 'CRP', unit: 'mg/L', lo: 0, hi: 9, pts: P('04-03|9 05-04|17 05-05|194 05-06|51 05-07|29 11-04|12') },
    { name: '알부민', abbr: 'ALB', unit: 'g/dL', lo: 2.6, hi: 4.0, pts: P('03-20|3.2 04-03|3.0 04-10|3.3 05-02|3.4 05-05|3.4|P 08-29|2.3 09-02|2.4 09-30|2.8 10-21|2.9 11-04|2.8') },
  ]},
  { title: '췌장', sub: 'cPL', items: [
    { name: '췌장 리파아제', abbr: 'cPL', unit: 'ng/mL', lo: 0, hi: 200, pts: P('05-05|307.5 10-21|679.9 11-04|352') },
  ]},
  { title: '단백뇨', sub: 'UPC', items: [
    { name: '요단백/크레아티닌비', abbr: 'UPC', unit: '', lo: 0, hi: 0.5, pts: P('04-25|26.53 09-30|8.68 10-21|7.56') },
  ]},
  { title: '체중 · 혈압', sub: '진료 시 측정값', items: [
    { name: '체중', abbr: 'BW', unit: 'kg', lo: null, hi: null, pts: P('03-20|4.4 03-24|4.54|S 04-03|4.58 04-10|4.45 04-28|4.2 05-02|3.82 05-07|3.77 05-12|3.68 06-18|3.88 07-02|3.95 07-22|3.92 08-12|3.94 08-29|4.54 09-02|4.32 09-09|4.05 09-16|4.07 09-30|4.1 10-09|4.05 10-21|4.04 10-28|3.93 11-04|3.95') },
    { name: '수축기 혈압', abbr: 'SBP', unit: 'mmHg', lo: null, hi: null, pts: P('03-20|140 03-24|150|S 04-03|140 04-10|160 05-02|200') },
  ]},
];
let DATA = BASE_DATA.map(sec => ({ ...sec, items: sec.items.filter(s => s.pts.length) })).filter(sec => sec.items.length);
const LAB_KEY = 'sungi-labs-user-v1';
const DMAP0 = { ...DMAP };
const toMD = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? `${m[2]}-${m[3]}` : null; };
const applyUserLabs = entries => {
  Object.keys(DMAP).forEach(k => delete DMAP[k]); Object.assign(DMAP, DMAP0);
  let maxT = Date.UTC(2026, 10, 10);
  DATA = BASE_DATA.map(sec => ({ ...sec, items: sec.items.map(s => {
    let pts = s.pts;
    entries.forEach(e => { const v = e.vals[s.abbr]; if (v == null || v === '' || isNaN(+v)) return; pts = [...pts.filter(p => p.d !== e.d), { d: e.d, v: +v, h: e.h || 'P' }]; });
    return pts === s.pts ? s : { ...s, pts: [...pts].sort((a, b) => toT(a.d) - toT(b.d)) };
  }).filter(s => s.pts.length) })).filter(sec => sec.items.length);
  entries.forEach(e => { DMAP[e.d] = e.h || 'P'; maxT = Math.max(maxT, toT(e.d) + 10 * 864e5); });
  T1 = maxT;
};
let USER_LABS = []; try { USER_LABS = JSON.parse(localStorage.getItem(LAB_KEY) || '[]') || []; } catch (e) {}
try { if (localStorage.getItem('sungi-labfix-1028') !== '1') {
  const FIX = { RETIC: 94.9, NEU: 13.43, 'K⁺': 5.44, BW: 3.93, 'Na⁺': 136, 'Cl⁻': 111, CREA: 2.91, BUN: 138.3, PHOS: 10, HCT: 25.4, HGB: 9.4, MCV: 49.2, WBC: 15.86, PLT: 892 };
  let ch = false;
  USER_LABS = USER_LABS.map(e => e && e.d === '10-28' ? (ch = true, { ...e, vals: { ...(e.vals || {}), ...Object.fromEntries(Object.entries(FIX).map(([k, v]) => [k, String(v)])) } }) : e);
  if (ch) localStorage.setItem(LAB_KEY, JSON.stringify(USER_LABS));
  localStorage.setItem('sungi-labfix-1028', '1');
} } catch (e) {}
applyUserLabs(USER_LABS);
const CHART_PDFS = [{"f":"labs/260320.pdf","t":"03.20"},{"f":"labs/260324.pdf","t":"03.24"},{"f":"labs/260324_blood.pdf","t":"03.24 혈액검사"},{"f":"labs/260403.pdf","t":"04.03"},{"f":"labs/260408.pdf","t":"04.08"},{"f":"labs/260410.pdf","t":"04.10"},{"f":"labs/260425-26.pdf","t":"04.25~26"},{"f":"labs/260425_pericardio.pdf","t":"04.25 심낭수 천자"},{"f":"labs/260426-0507.pdf","t":"04.26~05.07"},{"f":"labs/260427.pdf","t":"04.27"},{"f":"labs/260428.pdf","t":"04.28"},{"f":"labs/260502.pdf","t":"05.02"},{"f":"labs/260505.pdf","t":"05.05"},{"f":"labs/260507.pdf","t":"05.07"},{"f":"labs/260512.pdf","t":"05.12"},{"f":"labs/260524_1.pdf","t":"05.24 (1)"},{"f":"labs/260524_2.pdf","t":"05.24 (2)"},{"f":"labs/260524_3.pdf","t":"05.24 (3)"},{"f":"labs/260618.pdf","t":"06.18"},{"f":"labs/260702.pdf","t":"07.02"},{"f":"labs/260722.pdf","t":"07.22"},{"f":"labs/260812.pdf","t":"08.12"},{"f":"labs/260829.pdf","t":"08.29"},{"f":"labs/260902.pdf","t":"09.02"},{"f":"labs/260909.pdf","t":"09.09"},{"f":"labs/260916.pdf","t":"09.16"},{"f":"labs/260930.pdf","t":"09.30"},{"f":"labs/261009.pdf","t":"10.09"},{"f":"labs/261021.pdf","t":"10.21"},{"f":"labs/261028.pdf","t":"10.28"},{"f":"labs/261030.pdf","t":"10.30"},{"f":"labs/261031.pdf","t":"10.31"},{"f":"labs/261104.pdf","t":"11.04"}];
const emptyLf = () => ({ iso: '', h: 'P', vals: {}, auto: {}, files: [], editId: null, busy: '', msg: '' });
const idb = (() => {
  let p;
  const open = () => p || (p = new Promise((res, rej) => { const r = indexedDB.open('sungi-files', 1); r.onupgradeneeded = () => r.result.createObjectStore('f'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }));
  const tx = (mode, fn) => open().then(db => new Promise((res, rej) => { const t = db.transaction('f', mode); const q = fn(t.objectStore('f')); t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }));
  return { put: (k, v) => tx('readwrite', s => s.put(v, k)), get: k => tx('readonly', s => s.get(k)), del: k => tx('readwrite', s => s.delete(k)) };
})();
const LAB_KEYS = { CREA: ['CREA', 'Creatinine'], BUN: ['BUN', 'Urea'], PHOS: ['PHOS', 'IP', 'Phosphorus'], SDMA: ['SDMA'], 'Na⁺': ['Na'], 'K⁺': ['K'], 'Cl⁻': ['Cl'], HCT: ['HCT'], HGB: ['HGB', 'Hb'], RETIC: ['RETIC'], MCV: ['MCV'], WBC: ['WBC'], NEU: ['NEU'], PLT: ['PLT'], ALKP: ['ALKP', 'ALP'], ALT: ['ALT', 'GPT'], CRP: ['CRP'], ALB: ['ALB', 'Albumin'], BW: ['BW', '체중'], SBP: ['SBP'], cPL: ['Spec cPL', 'cPL', 'PL'], AST: ['AST', 'GOT'], GGT: ['GGT', 'GGTP'], TBIL: ['TBIL', 'T-Bil', 'TBil', 'Total Bilirubin'], UPC: ['UPC', 'UP/C', 'U-P/C'] };
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const parseLabText = txt => {
  const out = {}, src = {};
  const num = s => s.replace(/[<>\s,]/g, '');
  const want = Object.entries(LAB_KEYS).filter(([ab]) => ab !== 'BW');
  (txt || '').split('\n').forEach(ln => {
    const m = /^\s*(.+?)\s+([<>]?\s*-?\d[\d,]*(?:\.\d+)?)(?=\s|$)/.exec(ln);
    if (!m) return;
    const label = m[1].trim();
    if (/^%|[/()]/.test(label)) return;
    const words = label.split(/\s+/).map(w => w.replace(/^c(?=[A-Z])/, '').replace(/[+\-⁺⁻:]+$/, ''));
    want.forEach(([ab, keys]) => { if (out[ab] == null && keys.some(k => words.includes(k))) { out[ab] = num(m[2]); src[ab] = ln.trim(); } });
  });
  const bw = /(?:체중|BW)\s*[:：]?\s*(\d+(?:\.\d+)?)\s*kg/i.exec(txt || '');
  if (bw) out.BW = bw[1];
  want.forEach(([ab, keys]) => { if (out[ab] != null) return; for (const k of keys) { const m = new RegExp('(?:^|[^A-Za-z가-힣%(/])c?' + escRe(k) + '(?![A-Za-z가-힣/()\\-])[+\\-⁺⁻]?[^0-9<>\\n%]{0,10}([<>]?\\s*\\d[\\d,]*(?:\\.\\d+)?)', '').exec(txt || ''); if (m) { out[ab] = num(m[1]); break; } } });
  return out;
};
const LAB_PLAUS = { CREA: [0.1, 20], BUN: [2, 300], PHOS: [0.5, 25], SDMA: [0, 150], 'Na⁺': [100, 200], 'K⁺': [1.5, 10], 'Cl⁻': [70, 160], HCT: [5, 75], HGB: [2, 25], RETIC: [0, 600], MCV: [30, 100], WBC: [0.1, 150], NEU: [0, 120], PLT: [5, 2500], ALKP: [1, 5000], ALT: [1, 5000], CRP: [0, 500], ALB: [0.5, 6], BW: [0.5, 80], SBP: [50, 300], cPL: [0, 3000], AST: [1, 5000], GGT: [0, 500], TBIL: [0, 30], UPC: [0, 60] };
const labCheck = vals => {
  const odd = Object.entries(vals).filter(([k, v]) => LAB_PLAUS[k] && (isNaN(+v) || +v < LAB_PLAUS[k][0] || +v > LAB_PLAUS[k][1])).map(([k]) => k);
  const miss = ['CREA', 'BUN', 'PHOS', 'Na⁺', 'K⁺', 'Cl⁻', 'HCT'].filter(k => vals[k] == null || vals[k] === '');
  return { odd, miss };
};
const pdfText = async file => {
  const pdfjs = await import('https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.min.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs';
  const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  let t = '';
  for (let i = 1; i <= doc.numPages; i++) { const tc = await (await doc.getPage(i)).getTextContent(); t += tc.items.map(it => it.str + (it.hasEOL ? '\n' : ' ')).join('') + '\n'; }
  if (t.replace(/\s/g, '').length < 40) {
    for (let i = 1; i <= Math.min(doc.numPages, 6); i++) { const pg = await doc.getPage(i); const vp = pg.getViewport({ scale: 2 }); const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; await pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise; t += await ocr(c) + '\n'; }
  }
  return t.normalize('NFC');
};
let _tess = null;
const ocr = async src => {
  if (!_tess) _tess = (async () => {
    if (!window.Tesseract) await new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js'; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
    return window.Tesseract.createWorker(['kor', 'eng']);
  })();
  const w = await _tess;
  const r = await w.recognize(src);
  return (r.data.text || '').normalize('NFC');
};
const guessDate = (txt, name) => {
  let m = /(2026)\s*[.\-/년]\s*(\d{1,2})\s*[.\-/월]\s*(\d{1,2})/.exec(txt || '');
  if (m) return `2026-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  m = /(?:^|\D)26[.\-_ ]?(\d{2})[.\-_ ]?(\d{2})(?:\D|$)/.exec(name || '') || /2026(\d{2})(\d{2})/.exec(name || '');
  return m ? `2026-${m[1]}-${m[2]}` : '';
};
const guessHosp = txt => /심장/.test(txt) ? 'S' : /지중해/.test(txt) ? 'J' : /비엔/.test(txt) ? 'B' : /부평/.test(txt) ? 'P' : '';

const C = { hi: 'oklch(0.58 0.17 28)', lo: 'oklch(0.58 0.17 250)', ok: '#4A3A33' };
const status = (v, s) => (s.hi != null && v > s.hi) ? 'hi' : (s.lo != null && v < s.lo) ? 'lo' : 'ok';
const fmt = v => (Math.round(v * 100) / 100).toString();
const md = d => d.replace('-', '.');

function Chart({ s, showBand, byHosp }) {
  const ref = React.useRef(null);
  const [w, setW] = React.useState(340);
  const [hv, setHv] = React.useState(null);
  React.useEffect(() => {
    const upd = () => { if (ref.current) { const cw = ref.current.parentElement.getBoundingClientRect().width; if (cw) setW(Math.max(200, cw)); } };
    upd(); const id = setTimeout(upd, 300);
    const ro = new ResizeObserver(upd);
    if (ref.current) ro.observe(ref.current.parentElement);
    window.addEventListener('resize', upd);
    return () => { ro.disconnect(); clearTimeout(id); window.removeEventListener('resize', upd); };
  }, []);
  const H = 150, L = 8, R = 8, T = 12, B = 22;
  const vals = s.pts.map(p => p.v);
  let mn = Math.min(...vals), mx = Math.max(...vals);
  if (showBand && s.lo != null) { mn = Math.min(mn, s.lo); mx = Math.max(mx, s.hi); }
  const pad = (mx - mn) * 0.1 || 1; mn -= pad; mx += pad;
  if (s.lo === 0 && mn < 0) mn = 0;
  const X = t => L + (t - T0) / (T1 - T0) * (w - L - R);
  const Y = v => T + (1 - (v - mn) / (mx - mn)) * (H - T - B);
  const pts = s.pts.map(p => ({ ...p, x: X(toT(p.d)), y: Y(p.v), st: status(p.v, s) }));
  const d = pts.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(1) + ' ' + p.y.toFixed(1)).join(' ');
  const e = React.createElement;
  const months = [4,5,6,7,8,9,10].map(m => ({ m, x: X(Date.UTC(2026, m-1, 1)) }));
  const ev = X(Date.UTC(2026,3,25));
  const kids = [];
  months.forEach(o => {
    kids.push(e('line', { key: 'm'+o.m, x1: o.x, x2: o.x, y1: T, y2: H - B, stroke: '#F8E8E0' }));
    kids.push(e('text', { key: 't'+o.m, x: o.x + 3, y: H - 6, fontSize: 10.5, fill: '#BFA49A', fontFamily: 'IBM Plex Sans KR' }, o.m + '월'));
  });
  if (showBand && s.lo != null) {
    const y1 = Y(Math.min(s.hi, mx)), y2 = Y(Math.max(s.lo, mn));
    kids.push(e('rect', { key: 'band', x: L, y: y1, width: w - L - R, height: Math.max(0, y2 - y1), fill: 'oklch(0.94 0.035 150)' }));
  }
  kids.push(e('line', { key: 'ev', x1: ev, x2: ev, y1: T - 4, y2: H - B, stroke: '#BFA49A', strokeDasharray: '3 3' }));
  kids.push(e('line', { key: 'ax', x1: L, x2: w - R, y1: H - B, y2: H - B, stroke: '#EBCFC4' }));
  kids.push(e('path', { key: 'ln', d, fill: 'none', stroke: '#A88F86', strokeWidth: 1.4, strokeLinejoin: 'round' }));
  pts.forEach((p, i) => {
    const fill = byHosp ? `oklch(0.6 0.13 ${HOSP_HUE[p.h]})` : C[p.st];
    kids.push(e('circle', { key: 'p'+i, cx: p.x, cy: p.y, r: hv === i ? 5.5 : 3.6, fill, stroke: '#fff', strokeWidth: 1.5 }));
  });
  const onMove = ev2 => {
    const r = ref.current.getBoundingClientRect(); const mx2 = ev2.clientX - r.left;
    let bi = 0, bd = 1e9; pts.forEach((p, i) => { const dd = Math.abs(p.x - mx2); if (dd < bd) { bd = dd; bi = i; } });
    setHv(bd < 30 ? bi : null);
  };
  kids.push(e('rect', { key: 'hit', x: 0, y: 0, width: w, height: H, fill: 'transparent', onMouseMove: onMove, onMouseLeave: () => setHv(null) }));
  const hp = hv != null ? pts[hv] : null;
  const tip = hp && e('div', { style: { position: 'absolute', left: Math.min(Math.max(hp.x - 70, 0), w - 150), top: hp.y > 70 ? hp.y - 62 : hp.y + 12, width: 150, background: '#4A3A33', color: '#fff', borderRadius: 6, padding: '6px 9px', fontSize: 11.5, lineHeight: 1.45, pointerEvents: 'none', boxSizing: 'border-box' } },
    e('div', { style: { fontFamily: 'IBM Plex Mono, monospace', fontSize: 14 } }, fmt(hp.v) + ' ', e('span', { style: { fontSize: 11, opacity: 0.7 } }, s.unit)),
    e('div', { style: { opacity: 0.8 } }, '2026.' + md(hp.d) + ' · ' + HOSP[hp.h]));
  return e('div', { ref, style: { position: 'relative', width: w } },
    e('svg', { width: w, height: H, style: { display: 'block', overflow: 'visible' } }, kids), tip);
}

function Spark({ s }) {
  const e = React.createElement, W = 64, H = 26, P = 3;
  const vals = s.pts.map(p => p.v);
  let mn = Math.min(...vals), mx = Math.max(...vals);
  if (s.lo != null) { mn = Math.min(mn, s.lo); mx = Math.max(mx, s.hi); }
  const rg = (mx - mn) || 1;
  const X = t => P + (t - T0) / (T1 - T0) * (W - 2 * P), Y = v => P + (1 - (v - mn) / rg) * (H - 2 * P);
  const pts = s.pts.map(p => [X(toT(p.d)), Y(p.v)]);
  const last = s.pts[s.pts.length - 1], lp = pts[pts.length - 1];
  const kids = [];
  if (s.lo != null) { const y1 = Y(s.hi), y2 = Y(s.lo); kids.push(e('rect', { key: 'b', x: 0, y: y1, width: W, height: Math.max(1, y2 - y1), fill: 'oklch(0.94 0.035 150)', rx: 2 })); }
  kids.push(e('polyline', { key: 'l', points: pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' '), fill: 'none', stroke: '#A88F86', strokeWidth: 1.3, strokeLinejoin: 'round' }));
  kids.push(e('circle', { key: 'c', cx: lp[0], cy: lp[1], r: 2.8, fill: C[status(last.v, s)] }));
  return e('svg', { width: W, height: H, style: { display: 'block', overflow: 'visible' } }, kids);
}
const ECHO = {
  '03-27': ['IVSd 7.73 mm','LVIDd 24.55 mm','LVPWd 7.80 mm','LA Minor 19.57 mm','LA Major 24.47 mm','Ao 13.98 mm'],
  '04-21': ['LA/Ao 1.29'],
  '09-16': ['MV Peak E 124.16 cm/s','MV Peak A 150.77 cm/s','MV E/A 0.82','MR Vmax 564.49 cm/s','MR PGmax 127.46 mmHg','MPA 2.45 cm','D 2.81 cm','D 2.38 cm'],
  '09-30': ['MV E 131.75 cm/s','MV A 142.39 cm/s','E/A 0.93 · 0.83','TR Vmax 297.42 cm/s','TR PG 35.38 mmHg'],
};
const NOTES = {
  '03-24': ['ACTH 자극검사: pre 2.4 → post >10.0 μg/dL (참고 6–18)'],
  '04-25': ['심낭수 천자 시행 · 분석 결과 혈액성 유출액(hemorrhagic effusion)', 'UPC >26.53 (참고 ≤0.5)'],
  '05-04': ['D-dimer 750.32 (참고 50–250)'],
  '05-05': ['CRP 194 mg/L (참고 0–9) · 같은 날 부평 ABL80에서 K⁺ 6.0, iCa 0.83 측정', 'cPL 307.5 ng/mL (참고 50–200)'],
  '05-06': ['CRP 51 mg/L (부평 NX700)'],
  '05-07': ['CRP 29 mg/L (부평 NX700)'],
  '09-16': ['초음파 화면 측정: MR Vmax 5.64 m/s, MR PGmax 127.46 mmHg, MV E/A 0.82'],
  '09-30': ['UPC 8.68 (참고 ≤0.5) · ALP 1,018 U/L (부평 참고 13–83)'],
  '10-09': ['ALP 861 U/L (부평 참고 13–83)'],
  '11-04': ['ALP 1,048 U/L (부평 참고 13–83) · cPL 352 (참고 ≤200)', 'ABL9 혈액가스: pH 7.33 · cHCO₃⁻ 21 · iCa 1.36 · ctHb 5.4', 'NX700: BUN/CRE 35.9 · GLU 114 · TPRO 6.6 · GLOB 3.8'],
};
const IMG_NOTES = {
  '03-27': ['심장 초음파 보고서 포함 · 처음 측정한 값이라 이후 비교 기준으로 쓰기'],
  '04-21': ['화면에 "PERICARDIAL EF." 표기 · 4일 뒤 심낭수 천자 시행', 'LA/Ao 1.29 기록'],
  '04-27': ['심낭수 천자 이후 첫 영상 · 심낭수 재발 여부 소견 확인'],
  '05-05': ['CRP가 가장 높았던 날(194) · 같은 날 영상 소견 확인'],
  '08-29': ['체중 4.54 kg으로 증가한 날 · 복부 · 흉부 액체 여부 소견 확인', '복부 초음파에 우측 신장(RK) 표기 화면 있음'],
  '09-16': ['MV E-peak 1.24 m/s — 참고선 1.2 m/s 초과', 'MR Vmax 5.64 m/s, PG 127 mmHg 측정 · 다음 검사와 비교', '화면 측정 D 2.81 cm · D 2.38 cm · MPA 2.45 cm (측정 부위는 수의사 확인 필요)'],
  '09-30': ['MV E-peak 1.32 m/s — 1.2 m/s 초과, 09.16(1.24)보다 상승', 'TR Vmax 2.97 m/s · E/A 0.93 · 0.83 · 09.16 값과 비교'],
  '10-09': ['가장 최근 영상 · 이전 영상과 비교한 소견 요청'],
};
const TYPE_LABEL = { report: '초음파 보고서', xray: 'X-ray', us: '초음파', etc: '기타 영상' };

const MED_KEY = 'sungi-meds-v1';
const MEMO_KEY = 'sungi-memo-v1';
if (!Storage.prototype.__sungiPatched) {
  const orig = Storage.prototype.setItem;
  Storage.prototype.__sungiSet = orig;
  Storage.prototype.setItem = function (k, v) { orig.call(this, k, v); if (this === window.localStorage && String(k).startsWith('sungi-')) { if (window.__sungiCloud) window.__sungiCloud(String(k)); if (window.__sungiDirty) window.__sungiDirty(); } };
  Storage.prototype.__sungiPatched = true;
}

(function () {
  const inPopup = t => { let e = t; while (e && e !== document.body && e !== document) { if (e.nodeType === 1) { const st = (e.getAttribute && e.getAttribute('style')) || ''; if (/position:\s*fixed/.test(st) && /inset:\s*0/.test(st)) return true; } e = e.parentNode; } return false; };
  const popupOpen = () => !!Array.from(document.querySelectorAll('[style*="inset"]')).find(el => /position:\s*fixed/.test(el.getAttribute('style') || '') && /inset:\s*0/.test(el.getAttribute('style') || ''));
  document.addEventListener('scroll', e => {
    const t = e.target;
    if (t && t.nodeType === 1 && t.scrollLeft && inPopup(t)) t.scrollLeft = 0;
    if ((t === document || t === document.documentElement || t === document.body) && (window.scrollX || document.documentElement.scrollLeft) && popupOpen()) window.scrollTo(0, window.scrollY);
  }, true);
  window.addEventListener('scroll', () => { if (window.scrollX) window.scrollTo(0, window.scrollY); }, { passive: true });
})();

(function () {
  let sx = 0, sy = 0;
  const inPopup = t => { let e = t; while (e && e !== document.body && e !== document) { if (e.nodeType === 1) { const st = (e.getAttribute && e.getAttribute('style')) || ''; if (/position:\s*fixed/.test(st) && /inset:\s*0/.test(st)) return true; } e = e.parentNode; } return false; };
  let dir = null, pop = false;
  const hScroller = t => { let e = t; while (e && e.nodeType === 1) { if (e.scrollWidth > e.clientWidth + 1) { const o = getComputedStyle(e).overflowX; if (o === 'auto' || o === 'scroll') return true; } e = e.parentNode; } return false; };
  document.addEventListener('touchstart', e => { const t = e.touches[0]; if (t) { sx = t.clientX; sy = t.clientY; } dir = null; pop = inPopup(e.target) && !hScroller(e.target); }, { passive: true });
  document.addEventListener('touchmove', e => { if (!pop || e.touches.length > 1) return; const t = e.touches[0]; if (!t) return;
    if (!dir) { const dx = Math.abs(t.clientX - sx), dy = Math.abs(t.clientY - sy); if (dx < 6 && dy < 6) return; dir = dx > dy * 1.3 ? 'h' : 'v'; }
    if (dir === 'h' && e.cancelable) e.preventDefault(); }, { passive: false });
  document.addEventListener('touchend', () => { dir = null; pop = false; }, { passive: true });
  document.addEventListener('touchcancel', () => { dir = null; pop = false; }, { passive: true });
  document.addEventListener('wheel', e => { if (Math.abs(e.deltaX) > Math.abs(e.deltaY) && inPopup(e.target)) e.preventDefault(); }, { passive: false });
})();

(function () {
  const META = 'meta-sungi-at';
  const raw = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const rawSet = (k, v) => { try { (Storage.prototype.__sungiSet || Storage.prototype.setItem).call(localStorage, k, v); } catch (e) {} };
  const getMeta = () => { try { return JSON.parse(raw(META) || '{}') || {}; } catch (e) { return {}; } };
  let coll = null, ready = false; const timers = {}, pending = new Set();
  const push = async k => { if (!coll) return; try { const v = raw(k); if (v == null) return; await coll.doc(k).set({ v, at: getMeta()[k] || Date.now() }); } catch (e) { console.warn('[sungi] cloud save failed', k, e && e.code); } };
  window.__sungiCloud = k => { const m = getMeta(); m[k] = Date.now(); rawSet(META, JSON.stringify(m)); if (!ready) { pending.add(k); return; } clearTimeout(timers[k]); timers[k] = setTimeout(() => push(k), 700); };
  (async () => {
    try {
      if (!window.claude || !window.claude.use) return;
      const db = await window.claude.use('db'); const user = await window.claude.use('user');
      if (!db || !user || !user.id) return;
      const uid = await user.id(); if (!uid) return;
      coll = db.collection('data/users/' + uid);
      const snap = await coll.get();
      const meta = getMeta(); let changed = false; const remote = {};
      snap.docs.forEach(d => { const o = d.data() || {}; if (d.id.startsWith('sungi-') && typeof o.v === 'string') remote[d.id] = o; });
      Object.keys(remote).forEach(k => { const o = remote[k]; const lv = raw(k); if (lv == null || (meta[k] && (o.at || 0) > meta[k])) { if (lv !== o.v) { rawSet(k, o.v); changed = true; } meta[k] = o.at || Date.now(); } });
      const toPush = [];
      try { Object.keys(localStorage).filter(k => k.startsWith('sungi-')).forEach(k => { const o = remote[k]; if (!o || !meta[k] || meta[k] > (o.at || 0)) { if (!meta[k]) meta[k] = Date.now(); toPush.push(k); } }); } catch (e) {}
      rawSet(META, JSON.stringify(meta));
      for (const k of toPush) await push(k);
      ready = true;
      pending.forEach(k => push(k)); pending.clear();
      if (changed && String(window.name).indexOf('sungiR') < 0) { window.name = String(window.name) + 'sungiR'; location.reload(); }
    } catch (e) { console.warn('[sungi] cloud sync unavailable', e && e.code); ready = false; }
  })();
})();
const BK = {
  b64: blob => new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.onerror = () => r(null); fr.readAsDataURL(blob); }),
  async build() {
    const ls = {}; Object.keys(localStorage).filter(k => k.startsWith('sungi-')).forEach(k => { ls[k] = localStorage.getItem(k); });
    let labs = []; try { labs = JSON.parse(ls['sungi-labs-user-v1'] || '[]'); } catch (e) {}
    const files = {};
    for (const e of labs) for (const f of e.files || []) { try { const b = await idb.get(f.key); if (b) files[f.key] = await BK.b64(b); } catch (x) {} }
    return JSON.stringify({ app: 'sungi', v: 1, savedAt: new Date().toISOString(), ls, files });
  },
  async restore(txt) {
    const o = JSON.parse(txt);
    if (!o || o.app !== 'sungi' || !o.ls) throw new Error('bad');
    const set = Storage.prototype.__sungiSet || Storage.prototype.setItem;
    Object.keys(localStorage).filter(k => k.startsWith('sungi-')).forEach(k => localStorage.removeItem(k));
    Object.entries(o.ls).forEach(([k, v]) => set.call(localStorage, k, v));
    for (const [k, d] of Object.entries(o.files || {})) { try { const b = await (await fetch(d)).blob(); await idb.put(k, b); } catch (x) {} }
  },
};
const hhmm = () => { const d = new Date(); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
const RX = [
  { id: 'pimo', g: 0, name: '피모벤단', dose: 1, step: 0.5, unit: '알', tabMg: 2.5, freq: '아침 · 저녁' },
  { id: 'gaba', g: 1, name: '가바펜틴', dose: 6, step: 0.5, unit: 'mpk', freq: '하루 2회' },
  { id: 'amlo', g: 1, name: '암로디핀', dose: 0.2, step: 0.05, unit: 'mpk', freq: '하루 2회' },
  { id: 'irbe', g: 1, name: '이르베사르탄', dose: 5, step: 0.5, unit: 'mpk', freq: '하루 1회' },
  { id: 'sily', g: 2, name: '실리마린', dose: 10, step: 1, unit: 'mpk', freq: '하루 2회' },
  { id: 'udca', g: 2, name: 'UDCA', dose: 10, step: 1, unit: 'mpk', freq: '하루 2회' },
  { id: 'lepo', g: 2, name: '레포틸', dose: 1, step: 0.1, unit: 'mpk', freq: '하루 2회' },
  { id: 'meto', g: 3, name: '메토클로프라마이드', dose: 0.32, step: 0.02, unit: 'mpk', freq: '하루 2회' },
  { id: 'famo', g: 3, name: '파모티딘', dose: 0.5, step: 0.05, unit: 'mpk', freq: '하루 2회' },
  { id: 'ondan', g: 3, name: '온단세트론', dose: 0.5, step: 0.05, unit: 'mpk', freq: '하루 2회' },
  { id: 'maro', g: 3, name: '마로피턴트', dose: 1, step: 0.1, unit: 'mpk', freq: '하루 1회' },
  { id: 'bease', g: 3, name: 'Bease', dose: 0.02, step: 0.005, unit: 'T/kg', freq: '–' },
  { id: 'samsca', g: 4, name: '삼스카 (톨밥탄) 30 mg', dose: 0.25, step: 0.25, unit: '정', tabMg: 30, freq: '아침 1회' },
];
const SUP = [
  { id: 'fet', name: '훼르콥상', amt: 6, step: 0.5, unit: 'cc', when: '아침 또는 저녁' },
  { id: 'fuco', name: '후코아이 블루', amt: 1, step: 0.5, unit: '알', when: '아침 · 저녁' },
  { id: 'renadil', name: '레나딜', amt: 1, step: 0.5, unit: '알', when: '식후' },
  { id: 'renamezin', name: '레나메진', amt: 2, step: 0.5, unit: '알', when: '다른 약과 앞뒤 2시간 간격' },
  { id: 'fosrenol', name: '포스레놀', amt: 500, step: 50, unit: 'mg', when: '밥과 함께' },
  { id: 'renvela', name: '렌벨라', amt: 200, step: 50, unit: 'mg', when: '밥과 함께' },
  { id: 'antares', name: '안타레스', amt: 1, step: 0.5, unit: '알', when: '아침 · 저녁' },
  { id: 'probio', name: '묘견서 유산균', amt: 1, step: 0.5, unit: '알', when: '아침 공복' },
  { id: 'activate', name: '액티베이트', amt: 1, step: 0.5, unit: '알', when: '아침 · 저녁' },
  { id: 'cobal', name: '프로텍신 코발라민', amt: null, when: '2일에 1회' },
];
const RX_V = 2;
const latestBW = () => { const s = DATA.flatMap(sec => sec.items).find(x => x.abbr === 'BW'); return s && s.pts.length ? s.pts[s.pts.length - 1] : null; };
const wAuto = b => { const l = latestBW(); return l ? { ...b, w: l.v } : b; };
const medDefaults = () => ({ rxV: RX_V, w: 4, rx: Object.fromEntries(RX.map(m => [m.id, m.dose])), sup: Object.fromEntries(SUP.map(m => [m.id, m.amt ?? 0])), at: null });

const _srcRefs = {};
const srcRef = u => _srcRefs[u] || (_srcRefs[u] = el => { if (el && el.getAttribute('src') !== u) el.setAttribute('src', u); });
const DIET_KEY = 'sungi-diet-v1';
const NUT = [
  { k: 'kcal', label: '열량', unit: 'kcal', r: 10 },
  { k: 'prot', label: '단백질', unit: 'g', r: 100 },
  { k: 'fat', label: '지방', unit: 'g', r: 100 },
  { k: 'carb', label: '탄수화물', unit: 'g', r: 10 },
  { k: 'p', label: '인', unit: 'mg', r: 10 },
  { k: 'k', label: '칼륨', unit: 'mg', r: 10 },
  { k: 'na', label: '나트륨', unit: 'mg', r: 10 },
  { k: 'h2o', label: '수분', unit: 'ml', r: 1 },
];
const TUNA_G = { kcal: 4.5, prot: 0.134, fat: 0.057, carb: null, p: 2, k: 4, na: 1.6, h2o: 0.14 };
const tunaOf = w => Object.fromEntries(Object.entries(TUNA_G).map(([k, v]) => [k, v == null ? '' : Math.round(v * w * 100) / 100]));
const TUNA_W = 5;
const DIET_KEY2 = 'sungi-diet-v2';
const valsStr = o => Object.fromEntries(NUT.map(n => [n.k, o[n.k] == null || o[n.k] === '' ? '' : String(Math.round(o[n.k] * 1000) / 1000)]));
const numOr = v => v === '' || v == null || isNaN(+v) ? null : +v;
const RC_DRY_100 = { kcal: 398.4, prot: 14, fat: 18, carb: 52.6, p: 200, k: 600, na: 350, h2o: 9.5 };
const RC_DRY = () => ({ id: 'rcdry', name: '로얄캐닌 레날 스몰독', memo: '1.5 kg · 100 g = 398.4 kcal', unit: 'g', step: '1', basis: '100', vals: valsStr(RC_DRY_100), imgs: [], url: '' });
const YUME = () => ({ id: 'yume', name: '키세이 신 유메고항 1/40', memo: '180 g = 268 kcal · 단백질 일반 밥의 1/40', unit: 'g', step: '5', basis: '180', vals: valsStr({ kcal: 268, prot: 0.11, fat: 0.6, carb: 65.4, p: 24, k: 0, na: 3.5 }), imgs: [], url: '' });
const RINGER_W = 10;
const ringerOf = w => { const pr = 0.047 * w, ft = 0.018 * w, cb = 0.159 * w; return { kcal: Math.round((pr * 3.5 + ft * 8.5 + cb * 3.5) * 10) / 10, prot: Math.round(pr * 100) / 100, fat: Math.round(ft * 100) / 100, carb: Math.round(cb * 100) / 100, p: Math.round(0.5 * w * 10) / 10, k: '', na: '', h2o: Math.round((100 + 0.035 * w) * 10) / 10 }; };
const RINGER = (w = RINGER_W) => ({ id: 'ringer', name: '링거독 플러스 치킨맛', memo: '1포 + 물 100 ml · 아침·저녁 20 ml씩 (하루 40 ml)', unit: 'ml', step: '5', basis: '100', vals: valsStr(ringerOf(w)), imgs: [], url: '' });
const defFoods = () => [
  RC_DRY(),
  { id: 'water', name: '물', memo: '', unit: 'ml', step: '10', basis: '1', vals: valsStr({ kcal: 0, prot: 0, fat: 0, carb: 0, p: 0, k: 0, na: 0, h2o: 1 }), imgs: [], url: '' },
  { id: 'rice', name: '햇반 저단백밥', memo: '180 g = 280 kcal', unit: 'g', step: '5', basis: '180', vals: valsStr({ kcal: 280, prot: 0.4, fat: 1.1, carb: 67, na: 10 }), imgs: [], url: '' },
  YUME(),
  RINGER(),
  { id: 'renal', name: '로얄캐닌 레날 리퀴드', memo: '1 ml = 1.5 kcal', unit: 'ml', step: '1', basis: '100', vals: valsStr({ kcal: 150, prot: 5, fat: 8, carb: 14, p: 110, k: 170, na: 130, h2o: 79.2 }), imgs: [], url: '' },
];
const compressImg = file => new Promise(res => {
  const fr = new FileReader();
  fr.onload = () => { const im = new Image(); im.onload = () => { const s = Math.min(1, 1600 / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * s); c.height = Math.round(im.height * s); const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.82)); }; im.onerror = () => res(null); im.src = fr.result; };
  fr.onerror = () => res(null); fr.readAsDataURL(file);
});
const dietBase = () => {
  const def = { foods: defFoods(), ringerV: 2, amt: { rcdry: 68, water: 190, rice: 60, yume: 0, ringer: 40, renal: 10 }, tunaW: TUNA_W, at: null };
  let s = null; try { s = JSON.parse(localStorage.getItem(DIET_KEY2) || 'null'); } catch (e) {}
  if (s && Array.isArray(s.foods)) {
    if (s.foods.some(f => f.id === 'tuna')) {
      const tw = s.tunaW || TUNA_W, ta = s.amt && s.amt.tuna != null ? +s.amt.tuna : 12;
      const g = Math.round(ta * tw * TUNA_G.kcal / (RC_DRY_100.kcal / 100));
      const amt = { ...(s.amt || {}) }; delete amt.tuna; amt.rcdry = g;
      s = { ...s, foods: s.foods.map(f => f.id === 'tuna' ? RC_DRY() : f), amt };
    }
    if (!s.foods.some(f => f.id === 'yume')) { const i = s.foods.findIndex(f => f.id === 'rice'); const fs = [...s.foods]; fs.splice(i < 0 ? fs.length : i + 1, 0, YUME()); s = { ...s, foods: fs, amt: { ...(s.amt || {}), yume: 0 } }; }
    if (s.foods.some(f => f.id === 'ringer') && s.ringerV !== 2) s = { ...s, ringerV: 2, foods: s.foods.map(f => f.id === 'ringer' ? { ...f, vals: valsStr(ringerOf(s.ringerW || RINGER_W)) } : f) };
    if (!s.foods.some(f => f.id === 'ringer')) { const i = s.foods.findIndex(f => f.id === 'yume'); const fs = [...s.foods]; fs.splice(i < 0 ? fs.length : i + 1, 0, RINGER()); s = { ...s, foods: fs, amt: { ...(s.amt || {}), ringer: 40 } }; }
    return { ...def, ...s };
  }
  let o = null; try { o = JSON.parse(localStorage.getItem(DIET_KEY) || 'null'); } catch (e) {}
  if (!o) return def;
  const tw = o.tunaV === 3 && o.tunaW ? o.tunaW : TUNA_W;
  const oa = { ...(o.amt || {}) }; if (oa.tuna != null) { oa.rcdry = Math.round(+oa.tuna * tw * TUNA_G.kcal / (RC_DRY_100.kcal / 100)); delete oa.tuna; }
  return { ...def, amt: { ...def.amt, ...oa }, tunaW: tw, at: o.at || null };
};

const DRAFT_KEY = 'sungi-draft-v1';
const DRAFT_FIELDS = ['tab', 'memoDraft', 'memoForm', 'ckForm', 'vsForm', 'lf', 'labSheet', 'med', 'diet'];
const applyDraft = S => {
  let d = null; try { d = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null'); } catch (e) {}
  if (!d || typeof d !== 'object') return S;
  const o = { ...S };
  ['tab', 'memoDraft', 'memoForm', 'ckForm', 'vsForm', 'lf', 'labSheet'].forEach(k => { if (d[k] !== undefined && d[k] !== null) o[k] = d[k]; });
  if (d.med && d.med.rx && JSON.stringify({ ...d.med, at: 0 }) !== JSON.stringify({ ...S.medSaved, at: 0 })) o.med = { ...S.med, ...d.med, rx: { ...S.med.rx, ...d.med.rx }, sup: { ...S.med.sup, ...d.med.sup } };
  if (d.diet && Array.isArray(d.diet.foods) && JSON.stringify({ ...d.diet, at: 0 }) !== JSON.stringify({ ...S.dietSaved, at: 0 })) o.diet = d.diet;
  return o;
};
class Component extends DCLogic {
  state = (() => {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(MED_KEY) || 'null'); } catch (e) {}
    const def = medDefaults();
    if (saved && saved.rxV !== RX_V) { const rx = { ...(saved.rx || {}) }; delete rx.telmi; rx.amlo = 0.2; rx.irbe = 5; rx.ondan = 0.5; saved = { ...saved, rx, rxV: RX_V }; }
    const base = saved ? { ...def, ...saved, rx: { ...def.rx, ...saved.rx }, sup: { ...def.sup, ...saved.sup } } : def;
    const d = dietBase();
    let memos = []; try { memos = JSON.parse(localStorage.getItem(MEMO_KEY) || '[]') || []; } catch (e) {}
    return applyDraft({ gdUrl: (() => { try { return localStorage.getItem('sungi-gdrive-url') || ''; } catch (e) { return ''; } })(), memos, mob: true, mFilter: 'all', mOpen: null, mTbl: false, sel: null, lb: null, dims: {}, xlb: null, tab: 'labs', med: wAuto(base), medSaved: wAuto(base), diet: d, dietSaved: d, dEdit: null, dImg: null, dErr: '', labs: USER_LABS, labOpen: false, lf: emptyLf(), kcalW: null });
  })();
  checkVals() {
    const KEY = 'sungi-check-v1';
    if (!this._ck) { try { this._ck = JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) { this._ck = []; } }
    const list = this.state.ckList || this._ck;
    const save = l => { this._ck = l; try { localStorage.setItem(KEY, JSON.stringify(l)); } catch (e) {} this.setState({ ckList: l }); };
    const today = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })();
    const F = this.state.ckForm, flt = this.state.ckFilter || 'all';
    const KIND = { ask: '물어볼 것', todo: '할 일' };
    const opt = (on, pick, label) => ({ label, pick, bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#6B5850', bd: on ? '#4A3A33' : '#F5DDD4' });
    const setF = p => this.setState(s => ({ ckForm: { ...s.ckForm, ...p } }));
    const shown = list.filter(c => flt === 'all' || (flt === 'open' ? !c.done : c.done));
    const byD = {}; shown.forEach(c => { (byD[c.date || ''] = byD[c.date || ''] || []).push(c); });
    const dk = Object.keys(byD).sort((a, b) => (a === '' ? 1 : b === '' ? -1 : b.localeCompare(a)));
    const DOW = ['일', '월', '화', '수', '목', '금', '토'];
    const ckGroups = dk.map(d => {
      const all = list.filter(c => (c.date || '') === d), done = all.filter(c => c.done).length;
      const dt = d ? new Date(d + 'T00:00:00') : null;
      const diff = dt ? Math.round((dt - new Date(today + 'T00:00:00')) / 864e5) : null;
      return { label: d ? `${d.slice(5, 7)}.${d.slice(8, 10)} (${DOW[dt.getDay()]})` : '날짜 없음', sub: diff == null ? '' : diff === 0 ? '오늘 진료' : diff > 0 ? `D-${diff}` : '지난 진료',
        prog: `${done}/${all.length}`, progColor: done === all.length ? 'oklch(0.50 0.12 150)' : '#9A7F74',
        items: byD[d].sort((a, b) => a.at - b.at).map(c => {
          const armed = this.state.ckDel === c.id;
          return { text: c.text, kind: KIND[c.kind] || '', kindColor: c.kind === 'ask' ? 'oklch(0.50 0.13 250)' : 'oklch(0.52 0.13 40)',
            check: c.done ? '✓' : '', boxBg: c.done ? '#4A3A33' : '#FFFFFF', boxBd: c.done ? '#4A3A33' : '#CDB5AB', fg: c.done ? '#A88F86' : '#4A3A33', lineW: c.done ? '100% 2px' : '0% 2px',
            toggle: () => save(list.map(x => x.id === c.id ? { ...x, done: !x.done, doneAt: !x.done ? Date.now() : null } : x)),
            edit: () => this.setState({ ckForm: { id: c.id, kind: c.kind, text: c.text, date: c.date || '' } }),
            delText: armed ? '삭제' : '×', delColor: armed ? 'oklch(0.50 0.17 25)' : '#BFA49A', delSize: armed ? '13px' : '18px',
            del: () => save(list.filter(x => x.id !== c.id)) };
        }) };
    });
    const open = list.filter(c => !c.done).length;
    return {
      ckCount: list.length ? `남은 항목 ${open}개` : '',
      ckOpenFn: () => this.setState(s => ({ ckForm: s.ckForm ? null : { id: null, kind: 'ask', text: '', date: today } })),
      ckFormOpen: !!F, ckText: F ? F.text : '', ckDate: F ? F.date : '',
      ckOnText: e => setF({ text: e.target.value }), ckOnDate: e => setF({ date: e.target.value }),
      ckKinds: F ? [opt(F.kind === 'ask', () => setF({ kind: 'ask' }), '물어볼 것'), opt(F.kind === 'todo', () => setF({ kind: 'todo' }), '할 일')] : [],
      ckCancel: () => this.setState({ ckForm: null }), ckSubmitText: F && F.id ? '수정' : '추가',
      ckSubmit: () => { if (!F || !F.text.trim()) return; const item = { kind: F.kind, text: F.text.trim(), date: F.date || '' };
        save(F.id ? list.map(x => x.id === F.id ? { ...x, ...item } : x) : [...list, { id: 'k' + Date.now().toString(36), ...item, done: false, at: Date.now() }]); this.setState({ ckForm: null }); },
      ckFilters: [['all', '전체'], ['open', '남은 것'], ['done', '완료']].map(([k, l]) => opt(flt === k, () => this.setState({ ckFilter: k }), l)),
      ckGroups, ckEmpty: !ckGroups.length,
      ckEmptyText: list.length ? (flt === 'open' ? '남은 항목이 없어요. 모두 확인했어요!' : '해당하는 항목이 없어요.') : '다음 진료 때 물어볼 것이나 할 일을 + 항목 추가로 적어 두세요. 진료일별로 묶여서 보여요.',
    };
  }
  exportSheets() {
    const today = new Date(), ts = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const dset = new Set(); DATA.forEach(sec => sec.items.forEach(s => s.pts.forEach(p => dset.add(p.d))));
    const ds = [...dset].sort((a, b) => toT(b) - toT(a));
    const labs = [['구분', '항목', '약어', '단위', '참고범위', ...ds.map(d => '2026.' + md(d))]];
    DATA.forEach(sec => sec.items.forEach(s => { const by = {}; s.pts.forEach(p => { by[p.d] = p.v; }); labs.push([sec.title, s.name, s.abbr, s.unit, s.lo != null ? `${s.lo}–${s.hi}` : '', ...ds.map(d => by[d] ?? '')]); }));
    const mv = this.medVals(), dv = this.dietVals(), kv = this.kcalVals();
    const meds = [['구분', '이름', '용량', '단위', '횟수 · 시간', `1회 (${mv.wText} kg 기준)`]];
    mv.rx.forEach(m => meds.push(['처방약', m.name, m.inputVal, m.unit, m.freq, m.per]));
    mv.sup.forEach(m => meds.push(['보조제 · 영양제', m.name, m.hasAmt ? m.inputVal : '', m.hasAmt ? m.unit : '', m.when, '']));
    const diet = [['음식', '메모', '하루 급여량', ...dv.dCols]];
    dv.dRows.forEach(r => diet.push([r.name, r.src || '', r.text, ...r.cells.map(c => c.text)]));
    diet.push(['합계', '', '', ...dv.dTotals.map(x => x.value)]);
    const kcal = [['항목', '값'], ['체중', `${kv.kWText} kg`], ['기초 에너지 요구량 (RER)', `${kv.kRer} kcal/일`], ['필요 열량 (RER × 1.2~1.6)', `${kv.kNeed} kcal/일`], ['현재 식단 하루 열량', `${kv.kDiet} kcal`], ['비율', kv.kRatio || '']];
    const memos = [['날짜', '완료', '내용']]; [...(this.state.memos || [])].sort((a, b) => String(b.d).localeCompare(String(a.d))).filter(m => !m.auto).forEach(m => { const ch = (m.applied || []).filter(c => !c.undone).map(c => `${c.name} ${fmt(c.from)} → ${fmt(c.to)} ${c.unit}`).join(', '); memos.push([m.d || '', m.done ? 'O' : '', [m.text, ch && `(반영: ${ch})`].filter(Boolean).join(' ')]); });
    const KIND = { ask: '물어볼 것', todo: '할 일' };
    const checks = [['진료일', '구분', '완료', '내용']]; [...(this.state.ckList || this._ck || [])].sort((a, b) => String(b.date).localeCompare(String(a.date))).forEach(c => checks.push([c.date || '', KIND[c.kind] || '', c.done ? 'O' : '', c.text]));
    return { ts, sheets: [['검사 수치', labs], ['투약', meds], ['식단', diet], ['칼로리', kcal], ['메모', memos], ['체크리스트', checks]] };
  }
  exportVals() {
    const dl = (blob, name) => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); };
    const msg = m => this.setState({ exMsg: m });
    return {
      exMsg: this.state.exMsg || '',
      exTxt: () => {
        const { ts, sheets } = this.exportSheets();
        const L = [`숭이 건강 기록 · ${ts} 내보냄`, '포메라니안 · 중성화 수컷 · 2013년생', '※ 모든 기록은 최신 날짜가 먼저 나와요.', ''];
        sheets.forEach(([title, rows]) => {
          L.push('■ ' + title, '');
          if (title === '검사 수치') {
            const head = rows[0], dates = head.slice(5);
            rows.slice(1).forEach(r => { const vals = dates.map((d, i) => r[5 + i] === '' ? null : `${d.slice(5)} ${r[5 + i]}`).filter(Boolean); if (!vals.length) return; L.push(`· ${r[1]} (${r[2]}, ${r[3]}${r[4] ? ', 참고 ' + r[4] : ''})`); L.push('  ' + vals.slice(0, 8).join('  ·  ')); });
          } else if (rows.length <= 1) L.push('  (기록 없음)');
          else { const head = rows[0]; rows.slice(1).forEach(r => L.push('· ' + r.map((v, i) => v === '' ? null : (i === 0 ? v : `${head[i]} ${v}`)).filter(Boolean).join(' / '))); }
          L.push('');
        });
        dl(new Blob(['\ufeff' + L.join('\r\n')], { type: 'text/plain;charset=utf-8' }), `숭이_기록_${ts}.txt`); msg('메모장 파일을 저장했어요.');
      },
      exXlsx: async () => {
        const { ts, sheets } = this.exportSheets();
        msg('엑셀 파일 만드는 중…');
        try {
          if (!window.XLSX) await new Promise((res, rej) => { const s = document.createElement('script'); s.src = 'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js'; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
          const X = window.XLSX, wb = X.utils.book_new();
          sheets.forEach(([title, rows]) => { const ws = X.utils.aoa_to_sheet(rows); ws['!cols'] = rows[0].map((_, i) => ({ wch: Math.min(40, Math.max(8, ...rows.map(r => String(r[i] ?? '').length * 1.6))) })); ws['!freeze'] = { xSplit: 0, ySplit: 1 }; X.utils.book_append_sheet(wb, ws, title); });
          const out = X.write(wb, { bookType: 'xlsx', type: 'array' });
          dl(new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `숭이_기록_${ts}.xlsx`); msg('엑셀 파일을 저장했어요. 구글 시트에서도 바로 열 수 있어요.');
        } catch (e) {
          const esc = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
          const csv = sheets.map(([title, rows]) => [title, ...rows.map(r => r.map(esc).join(','))].join('\r\n')).join('\r\n\r\n');
          dl(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }), `숭이_기록_${ts}.csv`); msg('인터넷 연결 문제로 엑셀 대신 CSV 파일로 저장했어요. 엑셀·구글 시트에서 열 수 있어요.');
        }
      },
    };
  }
  bkVals() {
    const bk = this.state.bk || {};
    const canFS = typeof window.showSaveFilePicker === 'function';
    const writeTo = async h => { const w = await h.createWritable(); await w.write(await BK.build()); await w.close(); };
    const link = h => { this._fh = h; idb.put('__fs-handle', h).catch(() => {}); this.setState({ bk: { linked: true, name: h.name, msg: `${hhmm()} 저장됨` } }); };
    return {
      bkStatus: bk.linked ? `기록 파일 ${bk.name}에 자동 저장 중 · ${bk.msg || ''}` : (bk.msg || '기록이 이 브라우저에만 있습니다. 기록 파일로 저장해 두면 다른 기기나 브라우저에서 불러올 수 있습니다.'),
      bkColor: bk.linked ? 'oklch(0.45 0.12 150)' : '#9A7F74',
      bkCanRelink: !bk.linked && !!this._fhPending, bkRelinkText: this._fhPending ? `${this._fhPending.name}에 다시 연결` : '',
      bkRelink: async () => { const h = this._fhPending; if (!h) return; try { if ((await h.requestPermission({ mode: 'readwrite' })) !== 'granted') return; this._fhPending = null; await writeTo(h); link(h); } catch (e) { this.setState({ bk: { msg: '파일에 다시 연결하지 못했습니다.' } }); } },
      bkSave: async () => {
        const fname = `숭이-기록-${new Date().toISOString().slice(0, 10)}.json`;
        if (canFS) {
          try { const h = await window.showSaveFilePicker({ suggestedName: fname, types: [{ description: '숭이 기록', accept: { 'application/json': ['.json'] } }] }); await writeTo(h); link(h); }
          catch (e) { if (e && e.name !== 'AbortError') this.setState({ bk: { msg: '저장하지 못했습니다.' } }); }
          return;
        }
        const url = URL.createObjectURL(new Blob([await BK.build()], { type: 'application/json' }));
        const a = document.createElement('a'); a.href = url; a.download = fname; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
        this.setState({ bk: { msg: `${hhmm()} 기록 파일(${fname})을 내려받았습니다. 기록을 바꾼 뒤에는 다시 저장해 주세요.` } });
      },
      bkLoad: e => {
        const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return;
        if (!window.confirm('이 기록 파일로 현재 기록을 바꿀까요?')) return;
        f.text().then(t => BK.restore(t)).then(() => location.reload()).catch(() => this.setState({ bk: { msg: '숭이 기록 파일이 아니거나 읽을 수 없습니다.' } }));
      },
    };
  }
  kcalVals() {
    const bw = DATA.flatMap(sec => sec.items).find(s => s.abbr === 'BW');
    const lastBw = bw && bw.pts.length ? bw.pts[bw.pts.length - 1] : null;
    const mw = this.state.med.w; const raw = this.state.kcalW != null && numOr(this.state.kcalW) === mw ? this.state.kcalW : String(mw);
    const w = numOr(raw);
    const ok = w != null && w > 0;
    const pow = ok ? Math.pow(w, 0.75) : 0, rer = 70 * pow;
    const k0 = v => Math.round(v);
    const setW = v => { const n = Math.max(0.1, Math.round(v * 100) / 100); this.setState(s => ({ kcalW: null, med: { ...s.med, w: n } })); };
    const dt = this.state.diet;
    let dk = 0, miss = false;
    dt.foods.forEach(f => { const a = dt.amt[f.id] ?? 0, pv = numOr(f.vals.kcal), b = numOr(f.basis) || 100; if (pv == null) { if (a > 0) miss = true; return; } dk += pv / b * a; });
    const rows = [
      ['입원·회복 중인 아이의 출발점', 'RER × 1.0', 1.0, 1.0],
      ['활동량이 적거나 중성화한 성견', 'RER × 1.2~1.6', 1.2, 1.6],
      ['중성화하지 않은 일반 성견', 'RER × 1.4~1.8', 1.4, 1.8],
    ];
    const inRow = (lo, hi) => ok && dk >= rer * lo - 0.5 && dk <= rer * hi + 0.5;
    return {
      kW: raw, kOnW: e => { const v = e.target.value; const n = numOr(v); this.setState(s => (n != null && n > 0 ? { kcalW: v, med: { ...s.med, w: n } } : { kcalW: v })); },
      kDec: () => setW((ok ? w : 4) - 0.05), kInc: () => setW((ok ? w : 4) + 0.05),
      kUseLast: () => this.setState(s => ({ kcalW: null, med: { ...s.med, w: lastBw ? lastBw.v : s.med.w } })), kLastText: lastBw ? `최근 측정값 ${fmt(lastBw.v)} kg으로` : '',
      kWText: ok ? fmt(w) : '–', kPow: ok ? (Math.round(pow * 100) / 100).toFixed(2) : '–', kRer: ok ? k0(rer) : '–',
      kRows: rows.map(([label, f, lo, hi]) => ({ label, f, val: !ok ? '–' : lo === hi ? `약 ${k0(rer * lo)}kcal` : `약 ${k0(rer * lo)}~${k0(rer * hi)}kcal`, bg: inRow(lo, hi) ? 'oklch(0.95 0.035 250)' : 'transparent' })),
      kDiet: (miss ? '≥ ' : '') + k0(dk), kRatio: ok && rer ? `RER의 ${(dk / rer).toFixed(2)}배` : '',
      kNeed: ok ? `${k0(rer * 1.2)}~${k0(rer * 1.6)}` : '–',
      kEdited: !!lastBw && Math.abs(mw - lastBw.v) > 1e-9, kSrc: lastBw && Math.abs(mw - lastBw.v) <= 1e-9 ? `최근 측정 체중 자동 적용 (${md(lastBw.d)})` : '직접 수정한 체중 · 투약 화면과 함께 적용',
    };
  }
  askGd() {
    const v = (window.prompt('검사 자료가 있는 구글 드라이브 폴더 링크를 붙여넣어 주세요.', this.state.gdUrl || '') || '').trim();
    if (!v) return '';
    const u = /^https?:\/\//.test(v) ? v : 'https://' + v;
    try { localStorage.setItem('sungi-gdrive-url', u); } catch (e) {}
    this.setState({ gdUrl: u }); return u;
  }
  openLabSheet() {
    const used = new Set(this.state.labs.flatMap(e => e.files.map(f => f.key)));
    (this.state.lf.files || []).forEach(f => { if (!used.has(f.key)) idb.del(f.key).catch(() => {}); });
    this.setState({ tab: 'labs', labSheet: true, labOpen: false, lf: emptyLf() });
  }
  labVals() {
    const lf = this.state.lf, entries = this.state.labs;
    const setLf = p => this.setState(s => ({ lf: { ...s.lf, ...(typeof p === 'function' ? p(s.lf) : p) } }));
    const saveList = list => { try { localStorage.setItem(LAB_KEY, JSON.stringify(list)); } catch (e) { return false; } applyUserLabs(list); return true; };
    const used = new Set(entries.flatMap(e => e.files.map(f => f.key)));
    const openFile = f => idb.get(f.key).then(b => { if (!b) { window.alert('파일을 찾을 수 없습니다.'); return; } window.open(URL.createObjectURL(b), '_blank'); }).catch(() => window.alert('파일을 열 수 없습니다.'));
    const labGroups = BASE_DATA.map(sec => ({ title: sec.title, fields: sec.items.map(s => ({ abbr: s.abbr, name: s.name, unit: s.unit, value: lf.vals[s.abbr] ?? '', bg: lf.auto[s.abbr] ? 'oklch(0.94 0.04 250)' : '#FFFAF6', border: lf.auto[s.abbr] ? 'oklch(0.70 0.10 250)' : '#F5DDD4',
      onChange: e => { const v = e.target.value; setLf(l => ({ vals: { ...l.vals, [s.abbr]: v }, auto: { ...l.auto, [s.abbr]: false } })); } })) }));
    const hospOpts = Object.entries(HOSP).map(([k, name]) => ({ name, bg: lf.h === k ? '#4A3A33' : '#FFFFFF', fg: lf.h === k ? '#FFFFFF' : '#4A3A33', pick: () => setLf({ h: k }) }));
    const commit = (L, prefix) => {
      const d = toMD(L.iso);
      if (!d || !L.iso.startsWith('2026')) return { ok: false, msg: '검사 날짜를 찾지 못했습니다. 날짜를 입력하고 반영하기를 눌러 주세요.' };
      const vals = {}; Object.entries(L.vals).forEach(([k, v]) => { if (v !== '' && v != null && !isNaN(+v)) vals[k] = +v; });
      if (!Object.keys(vals).length && !L.files.length) return { ok: false, msg: '수치나 파일을 하나 이상 넣어 주세요.' };
      const cur = this.state.labs;
      let list = cur.filter(x => x.id !== L.editId);
      const same = list.find(x => x.d === d);
      const entry = same ? { ...same, h: L.h, vals: { ...same.vals, ...vals }, files: [...same.files, ...L.files] } : { id: 'L' + Date.now().toString(36), d, iso: L.iso, h: L.h, vals, files: L.files };
      list = [...list.filter(x => x.id !== entry.id), entry].sort((a, b) => toT(a.d) - toT(b.d));
      if (!saveList(list)) return { ok: false, msg: '저장 공간이 부족합니다.' };
      const names = Object.keys(vals);
      this.setState({ labs: list, sel: d, mDate: d, mFilter: 'all', mOpen: null, mJust: `${md(d)} ${HOSP[L.h] || ''} 검사 ${names.length}개 항목 반영됨`, lf: { ...emptyLf(), msg: `${prefix || ''}${md(d)} ${HOSP[L.h] || ''} 검사 ${names.length}개 항목을 표와 그래프에 반영했습니다${names.length ? ` (${names.join(', ')})` : ''}. 틀린 값은 아래 목록의 수정에서 고칠 수 있습니다.` } });
      return { ok: true };
    };
    const onFiles = e => {
      const files = [...(e.target.files || [])]; e.target.value = ''; if (!files.length) return;
      setLf({ busy: '파일 읽는 중…', msg: '' });
      (async () => {
        const metas = []; let found = {}, iso = '', hosp = '', err = '';
        for (const f of files) {
          const key = 'lab-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
          try { await idb.put(key, f); } catch (x) { err = '파일 저장에 실패했습니다.'; continue; }
          metas.push({ key, name: f.name, type: f.type });
          const isPdf = /pdf/i.test(f.type) || /\.pdf$/i.test(f.name), isImg = /^image\//i.test(f.type);
          let t = '';
          try {
            if (isPdf) { setLf({ busy: `${f.name} 읽는 중…` }); t = await pdfText(f); }
            else if (isImg) { setLf({ busy: `${f.name} 글자 인식 중… (처음엔 조금 걸립니다)` }); t = await ocr(f); }
          } catch (x) { err = `${f.name}의 글자를 읽지 못했습니다.`; }
          found = { ...parseLabText(t), ...found };
          if (!iso) iso = guessDate(t, f.name.normalize('NFC'));
          if (!hosp) hosp = guessHosp(t);
        }
        const L = { ...this.state.lf, busy: '', files: [...this.state.lf.files, ...metas], iso: this.state.lf.iso || iso, h: hosp || this.state.lf.h, vals: { ...this.state.lf.vals, ...found }, auto: { ...this.state.lf.auto, ...Object.fromEntries(Object.keys(found).map(k => [k, true])) } };
        const n = Object.keys(found).length;
        if (n) { const ck = labCheck(L.vals); const warn = [ck.odd.length ? `범위를 벗어난 값: ${ck.odd.join(', ')} — 원본과 꼭 대조해주세요.` : '', ck.miss.length ? `찾지 못한 항목: ${ck.miss.join(', ')} (검사하지 않았다면 비워두세요)` : ''].filter(Boolean).join('\n'); this.setState({ labOpen: true, lf: { ...L, msg: `${err ? err + ' ' : ''}${n}개 항목을 읽었어요. 날짜·병원·수치를 확인한 뒤 아래 저장 버튼을 눌러주세요.${warn ? '\n' + warn : ''}` } }); return; }
        this.setState({ labOpen: true, lf: { ...L, msg: err || '파일에서 수치를 찾지 못했습니다. 파일은 첨부됐으니 수치를 직접 입력해 주세요.' } });
      })();
    };
    const apply = () => { const r = commit(lf); if (!r.ok) setLf({ msg: r.msg }); else this.setState({ labSheet: false }); };
    const labEntries = entries.map(e => ({
      label: md(e.d), hosp: HOSP[e.h] || '', count: `${Object.keys(e.vals).length}개 항목`,
      files: e.files.map(f => ({ name: f.name, open: () => openFile(f) })),
      edit: () => this.setState({ labSheet: true, labOpen: true, lf: { ...emptyLf(), iso: e.iso || `2026-${e.d}`, h: e.h, vals: Object.fromEntries(Object.entries(e.vals).map(([k, v]) => [k, String(v)])), files: e.files, editId: e.id } }),
      del: () => { if (!window.confirm(`${md(e.d)} 검사 자료를 삭제할까요? 표와 그래프에서도 빠집니다.`)) return; const list = entries.filter(x => x.id !== e.id); saveList(list); e.files.forEach(f => idb.del(f.key).catch(() => {})); this.setState({ labs: list }); },
    }));
    return {
      labSheetOpen: !!this.state.labSheet, labSheetToggle: () => this.openLabSheet(), labSheetClose: () => this.setState({ labSheet: false }),
      lfArcOpen: !!this.state.lfArc, lfArcToggle: () => this.setState(s => ({ lfArc: !s.lfArc })), lfArcArrow: this.state.lfArc ? '접기 ▲' : '보기 ▼',
      gdHas: !!this.state.gdUrl, gdOpen: () => { let u = this.state.gdUrl; if (!u) { u = this.askGd(); if (!u) return; } window.open(u, '_blank'); }, gdEdit: () => this.askGd(),
      chartPdfs: CHART_PDFS.slice().reverse().map(x => ({ name: x.t, open: () => window.open(x.f, '_blank') })), chartPdfCount: `병원 진료차트 ${CHART_PDFS.length}개`,
      lfArcSub: `진료차트 ${CHART_PDFS.length}개 · 직접 올린 ${entries.length}회 · 파일 ${entries.reduce((n, e) => n + e.files.length, 0)}개`, labStop: e => e.stopPropagation(),
      labOpen: this.state.labOpen, labToggleText: this.state.labOpen ? '닫기' : '직접 입력',
      labToggle: () => this.setState(s => ({ labOpen: !s.labOpen })),
      lfIso: lf.iso, lfOnIso: e => { const v = e.target.value; setLf({ iso: v }); },
      hospOpts, labGroups, lfOnFiles: onFiles, lfBusy: lf.busy, lfMsg: lf.msg,
      lfFiles: lf.files.map((f, i) => ({ name: f.name, open: () => openFile(f), remove: () => { if (!used.has(f.key)) idb.del(f.key).catch(() => {}); setLf(l => ({ files: l.files.filter((_, j) => j !== i) })); } })),
      lfEditing: lf.editId ? '저장된 자료 수정 중' : '', lfApply: apply,
      lfReset: () => { lf.files.forEach(f => { if (!used.has(f.key)) idb.del(f.key).catch(() => {}); }); this.setState({ lf: emptyLf() }); },
      labEntries, labHasEntries: entries.length > 0,
    };
  }
  async autoNut(ed) {
    const id = ed.id, set = (o) => this.setState({ dAuto: { id, ...o } });
    const imgs = (ed.imgs || []).filter(s => /^data:image\//.test(s)).slice(0, 4);
    const url = /^https?:\/\//i.test(ed.url || '') ? ed.url.trim() : '';
    if (!imgs.length && !url) { set({ msg: '먼저 성분표 이미지를 첨부하거나 URL을 입력해주세요.', err: true }); return; }
    if (!window.claude || !window.claude.complete) { set({ msg: '자동 분석은 이 편집 화면에서만 동작해요. 배포한 페이지에서는 직접 입력해주세요.', err: true }); return; }
    set({ busy: true, msg: url ? '페이지 내용을 불러오는 중…' : '이미지를 분석하는 중…' });
    let pageText = '';
    if (url) {
      try { const r = await fetch('https://r.jina.ai/' + url, { headers: { Accept: 'text/plain' } }); if (r.ok) pageText = (await r.text()).slice(0, 30000); } catch (e) {}
      if (!pageText && !imgs.length) { set({ msg: '이 URL의 내용을 불러오지 못했어요. 성분표 부분을 캡처해서 이미지로 첨부해주세요.', err: true }); return; }
      set({ busy: true, msg: '성분을 분석하는 중…' });
    }
    const content = imgs.map(s => ({ type: 'image', source: { type: 'base64', media_type: s.slice(5, s.indexOf(';')), data: s.slice(s.indexOf(',') + 1) } }));
    content.push({ type: 'text', text: `반려동물 음식/사료/간식의 영양성분을 아래 자료에서 읽어 JSON 하나로만 답하세요. 다른 말은 쓰지 마세요.
형식: {"name":"제품명 또는 null","basis":숫자,"unit":"g" 또는 "ml","kcal":숫자|null,"prot":g|null,"fat":g|null,"carb":g|null,"p":mg|null,"k":mg|null,"na":mg|null,"h2o":ml|null,"note":"짧은 한국어 설명"}
규칙:
- 자료에 실제로 적힌 값만 사용하고, 없는 값은 null. 추측하지 마세요.
- 라벨이 "1회 제공량(예: 30 g)당" 이면 basis=30. "100 g당" 이면 basis=100.
- 등록성분량처럼 %로 적혀 있으면 basis=100, 단위 g 기준으로 환산(예: 조단백질 30% → prot 30, 인 0.5% → p 500 mg, 수분 10% → h2o 10).
- 열량이 kcal/kg이면 basis=100 기준으로 나누세요(3500 kcal/kg → 350).
- 조단백질=prot, 조지방=fat, 탄수화물=carb, 인=p, 칼륨=k, 나트륨=na, 수분=h2o.
- note에는 기준과 환산 여부, 없는 항목을 한 문장으로.${pageText ? '\n\n[URL 페이지 내용]\n' + pageText : ''}` });
    let raw = '';
    try { raw = await window.claude.complete({ model: 'claude-sonnet-4-5', max_tokens: 800, messages: [{ role: 'user', content }] }); }
    catch (e) { try { raw = await window.claude.complete({ max_tokens: 800, messages: [{ role: 'user', content }] }); } catch (e2) { set({ msg: '분석 중 오류가 났어요. 잠시 후 다시 시도해주세요.', err: true }); return; } }
    let j = null; try { j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1)); } catch (e) {}
    if (!j) { set({ msg: '성분표를 읽지 못했어요. 표가 잘 보이게 다시 찍어 첨부해주세요.', err: true }); return; }
    const filled = [], vals = {};
    NUT.forEach(n => { const v = j[n.k]; if (typeof v === 'number' && isFinite(v)) { vals[n.k] = String(Math.round(v * 1000) / 1000); filled.push(n.label); } });
    if (!filled.length) { set({ msg: '자료에서 성분값을 찾지 못했어요.' + (j.note ? '\n' + j.note : ''), err: true }); return; }
    this.setState(s => ({ dAuto: { id, msg: `${filled.join(' · ')} 입력 완료${j.note ? '\n' + j.note : ''}\n값을 라벨과 한 번 대조해주세요.` }, diet: { ...s.diet, foods: s.diet.foods.map(f => f.id !== id ? f : { ...f, name: f.name || (j.name && j.name !== 'null' ? j.name : ''), basis: typeof j.basis === 'number' && j.basis > 0 ? String(j.basis) : f.basis, unit: j.unit === 'ml' || j.unit === 'g' ? j.unit : f.unit, vals: { ...f.vals, ...vals } }) } }));
  }
  dietVals() {
    const cur = this.state.diet, sv = this.state.dietSaved;
    const r = v => Math.round(v * 1000) / 1000;
    const CH = 'oklch(0.50 0.15 250)';
    const tot = Object.fromEntries(NUT.map(n => [n.k, { v: 0, miss: false }]));
    const edId = this.state.dEdit; const LC = this.lastChgOf('diet');
    const upd = (id, fn) => this.setState(s => ({ diet: { ...s.diet, foods: s.diet.foods.map(f => f.id === id ? fn(f) : f) } }));
    const dRows = cur.foods.map(f => {
      const a = cur.amt[f.id] ?? 0, b = numOr(f.basis) || 100, st = numOr(f.step) || 1;
      const cells = NUT.map(n => {
        const pv = numOr(f.vals[n.k]);
        if (pv == null) { if (a > 0) tot[n.k].miss = true; return { text: '?', color: '#CDB5AB' }; }
        const v = pv / b * a; tot[n.k].v += v;
        return { text: v ? fmt(Math.round(v * n.r) / n.r) : '0', color: v ? '#4A3A33' : '#CDB5AB' };
      });
      const on = edId === f.id;
      const dr = (this.state.dDraft || {})[f.id];
      const setAmt = v => this.setState(s => ({ diet: { ...s.diet, amt: { ...s.diet.amt, [f.id]: v } } }));
      return { ...LC(f.id), name: f.name || '이름 없음', src: f.memo, text: `${fmt(a)} ${f.unit}`, unit: f.unit, inputVal: dr != null ? dr : fmt(a),
        onFocus: e => { const el = e.target; setTimeout(() => { try { el.select(); } catch (x) {} }, 0); },
        onInput: e => { const raw = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.'); this.setState(s => ({ dDraft: { ...(s.dDraft || {}), [f.id]: raw } })); const n = parseFloat(raw); if (raw !== '' && !isNaN(n) && n >= 0) setAmt(Math.round(n * 1000) / 1000); else if (raw === '') setAmt(0); },
        onBlur: () => this.setState(s => { const d = { ...(s.dDraft || {}) }; delete d[f.id]; return { dDraft: d }; }), color: a !== (sv.amt || {})[f.id] ? CH : '#4A3A33', cells,
        hasImg: (f.imgs || []).length > 0 || !!f.url, editLabel: on ? '수정 중' : '수정', editBg: on ? '#4A3A33' : '#FFFFFF', editFg: on ? '#FFFFFF' : '#6B5850',
        edit: () => this.setState(s => ({ dEdit: s.dEdit === f.id ? null : f.id })),
        del: () => { if (!window.confirm(`'${f.name || '이름 없음'}'을(를) 식단에서 삭제할까요?`)) return; this.setState(s => { const amt = { ...s.diet.amt }; delete amt[f.id]; return { dEdit: s.dEdit === f.id ? null : s.dEdit, diet: { ...s.diet, foods: s.diet.foods.filter(x => x.id !== f.id), amt } }; }); },
        dec: () => this.setState(s => ({ diet: { ...s.diet, amt: { ...s.diet.amt, [f.id]: Math.max(0, r((s.diet.amt[f.id] ?? 0) - st)) } } })),
        inc: () => this.setState(s => ({ diet: { ...s.diet, amt: { ...s.diet.amt, [f.id]: r((s.diet.amt[f.id] ?? 0) + st) } } })) };
    });
    const ed = cur.foods.find(f => f.id === edId) || null;
    const field = k => e => { const v = e.target.value; upd(edId, f => ({ ...f, [k]: v })); };
    const edVals = ed ? {
      edOpen: true, edName: ed.name, edMemo: ed.memo, edUnit: ed.unit, edStep: ed.step, edBasis: ed.basis, edUrl: ed.url || '',
      edIsTuna: false, edIsRinger: ed.id === 'ringer', edUnitG: (() => { const on = ed.unit !== 'ml'; return { pick: () => upd(edId, f => ({ ...f, unit: 'g' })), bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#6B5850', bd: on ? '#4A3A33' : '#F5DDD4' }; })(),
      edUnitMl: (() => { const on = ed.unit === 'ml'; return { pick: () => upd(edId, f => ({ ...f, unit: 'ml' })), bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#6B5850', bd: on ? '#4A3A33' : '#F5DDD4' }; })(),
      edSel: e => { const el = e.target; setTimeout(() => { try { el.select(); } catch (x) {} }, 0); }, edHasUrl: /^https?:\/\//i.test(ed.url || ''), edUrlHref: /^https?:\/\//i.test(ed.url || '') ? ed.url : '#',
      onName: field('name'), onMemo: field('memo'), onUnit: field('unit'), onStep: field('step'), onBasis: field('basis'), onUrl: field('url'),
      edNut: NUT.map(n => ({ label: n.label, unit: n.unit, value: ed.vals[n.k] ?? '', onChange: e => { const v = e.target.value; upd(edId, f => ({ ...f, vals: { ...f.vals, [n.k]: v } })); } })),
      edImgs: (ed.imgs || []).map((src, i) => ({ ref: srcRef(src), open: () => this.setState({ dImg: src }), remove: () => upd(edId, f => ({ ...f, imgs: f.imgs.filter((_, j) => j !== i) })) })),
      edNoImg: !(ed.imgs || []).length,
      onAddImg: e => { const files = [...(e.target.files || [])]; e.target.value = ''; const id = edId; Promise.all(files.map(compressImg)).then(list => { const ok = list.filter(Boolean); if (ok.length) upd(id, f => ({ ...f, imgs: [...(f.imgs || []), ...ok] })); }); },
      edClose: () => this.setState({ dEdit: null, dNew: null }),
      edAutoBusy: !!(this.state.dAuto && this.state.dAuto.busy), edAutoText: this.state.dAuto && this.state.dAuto.busy ? '분석 중…' : '성분표 자동 입력',
      edAutoHasMsg: !!(this.state.dAuto && this.state.dAuto.id === edId && this.state.dAuto.msg), edAutoMsg: (this.state.dAuto || {}).msg || '', edAutoColor: (this.state.dAuto || {}).err ? 'oklch(0.52 0.16 25)' : '#4A3A33',
      edAuto: () => this.autoNut(ed),
      edCancel: () => { if (this.state.dNew === edId) { this.setState(s => { const amt = { ...s.diet.amt }; delete amt[edId]; return { dEdit: null, dNew: null, diet: { ...s.diet, foods: s.diet.foods.filter(f => f.id !== edId), amt } }; }); } else this.setState({ dEdit: null }); },
      edStop: e => e.stopPropagation(),
      edTitle: this.state.dNew === edId ? '음식 추가' : `음식 편집 · ${ed.name}`, edNotNew: this.state.dNew !== edId, edDoneText: this.state.dNew === edId ? '식단에 추가' : '완료',
      edSwap: () => { if (!window.confirm('다른 사료로 바꿀까요? 이름·메모·영양성분·이미지·URL이 비워지고 급여량은 그대로 유지됩니다.')) return; upd(edId, f => ({ ...f, name: '', memo: '', basis: '100', vals: valsStr({}), imgs: [], url: '' })); },
      edDelete: () => { if (!window.confirm(`'${ed.name}'을(를) 식단에서 삭제할까요?`)) return; this.setState(s => { const amt = { ...s.diet.amt }; delete amt[edId]; return { dEdit: null, diet: { ...s.diet, foods: s.diet.foods.filter(f => f.id !== edId), amt } }; }); },
    } : { edOpen: false, edNut: [], edImgs: [] };
    const dAdd = () => { const id = 'f' + Date.now().toString(36); this.setState(s => ({ dEdit: id, dNew: id, diet: { ...s.diet, foods: [...s.diet.foods, { id, name: '', memo: '', unit: 'g', step: '', basis: '', vals: valsStr({}), imgs: [], url: '' }], amt: { ...s.diet.amt, [id]: 0 } } })); };
    const drink = Math.max(0, numOr(cur.drink) || 0) + Math.max(0, numOr(cur.fluid) || 0), drinkOnly = Math.max(0, numOr(cur.drink) || 0), fluid = Math.max(0, numOr(cur.fluid) || 0);
    const foodH2o = Math.round(tot.h2o.v);
    const dTotals = NUT.map(n => n.k === 'h2o'
      ? { label: '수분 (음수·수액 포함)', unit: n.unit, value: (tot.h2o.miss ? '≥ ' : '') + fmt(foodH2o + Math.round(drink)), note: tot.h2o.miss ? '일부 값 없음' : '' }
      : { label: n.label, unit: n.unit, value: (tot[n.k].miss ? '≥ ' : '') + fmt(Math.round(tot[n.k].v * n.r) / n.r), note: tot[n.k].miss ? '일부 값 없음' : '' });
    const drinkVals = { drinkVal: cur.drink == null ? '' : String(cur.drink),
      drinkOn: e => { const raw = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.'); this.setState(s => ({ diet: { ...s.diet, drink: raw === '' ? null : raw } })); },
      fluidVal: cur.fluid == null ? '' : String(cur.fluid),
      fluidOn: e => { const raw = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.'); this.setState(s => ({ diet: { ...s.diet, fluid: raw === '' ? null : raw } })); },
      drinkSel: e => { const el = e.target; setTimeout(() => { try { el.select(); } catch (x) {} }, 0); },
      drinkSum: `음식 수분 ${tot.h2o.miss ? '≥ ' : ''}${fmt(foodH2o)} ml + 음수 ${fmt(Math.round(drinkOnly))} ml + 피하수액 ${fmt(Math.round(fluid))} ml = 하루 ${tot.h2o.miss ? '≥ ' : ''}${fmt(foodH2o + Math.round(drink))} ml` };
    const tunaW = cur.tunaW ?? TUNA_W;
    const setTunaW = w => this.setState(s => ({ diet: { ...s.diet, tunaW: w, foods: s.diet.foods.map(f => f.id === 'tuna' ? { ...f, basis: '1', vals: valsStr(tunaOf(w)) } : f) } }));
    const tunaWText = `${fmt(tunaW)} g`;
    const ringerW = cur.ringerW ?? RINGER_W;
    const setRingerW = w => this.setState(s => ({ diet: { ...s.diet, ringerW: w, foods: s.diet.foods.map(f => f.id === 'ringer' ? { ...f, basis: '100', vals: valsStr(ringerOf(w)) } : f) } }));
    const ringerWText = `${fmt(ringerW)} g`;
    const ringerWDec = () => setRingerW(Math.max(1, Math.round((ringerW - 0.5) * 10) / 10));
    const ringerWInc = () => setRingerW(Math.min(30, Math.round((ringerW + 0.5) * 10) / 10));
    const tunaWDec = () => setTunaW(Math.max(4, Math.round((tunaW - 0.5) * 10) / 10));
    const tunaWInc = () => setTunaW(Math.min(6, Math.round((tunaW + 0.5) * 10) / 10));
    const dirty = JSON.stringify({ ...cur, at: 0 }) !== JSON.stringify({ ...sv, at: 0 });
    const at = sv.at ? new Date(sv.at) : null;
    return {
      ...drinkVals, dRows, dRowsM: dRows.map(r => ({ ...r, mcells: r.cells.map((c, i) => ({ ...c, label: NUT[i].label, unit: NUT[i].unit })) })), dTotals, ...edVals, dAdd, tunaWText, tunaWDec, tunaWInc, ringerWText, ringerWDec, ringerWInc, dErr: this.state.dErr,
      dImgOpen: !!this.state.dImg, dImgRef: srcRef(this.state.dImg || ''), dImgClose: () => this.setState({ dImg: null }), dCols: NUT.map(n => `${n.label} (${n.unit})`),
      dSaveStatus: dirty ? '저장되지 않은 변경 있음' : at ? `${at.getMonth() + 1}.${String(at.getDate()).padStart(2, '0')} ${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')} 저장됨` : '기본값',
      dSaveColor: dirty ? CH : '#A88F86', dSaveBg: dirty ? '#4A3A33' : '#A88F86',
      dSave: () => { const next = { ...this.state.diet, at: Date.now() }; try { localStorage.setItem(DIET_KEY2, JSON.stringify(next)); } catch (e) { this.setState({ dErr: '저장 공간이 부족해 저장하지 못했습니다. 이미지 수를 줄여주세요.' }); return; } this.setState({ diet: next, dietSaved: next, dErr: '' }); },
      dRevert: () => this.setState(s => ({ diet: s.dietSaved, dEdit: null, dNew: null })), dDirty: dirty, autoSaved: !!this.state.autoSavedAt,
    };
  }
  lastChgOf(kind) { const o = {}; (this.state.memos || []).forEach(m => { const ap = m.applied || (m.kind === kind && m.target && m.to != null ? [{ kind, target: m.target, from: m.from, to: m.to, unit: m.unit }] : []); ap.forEach(c => { if (c.kind !== kind || c.undone) return; const p = o[c.target]; if (!p || m.d > p.d || (m.d === p.d && (m.at || 0) > (p.at || 0))) o[c.target] = { d: m.d, at: m.at, from: c.from, to: c.to, unit: c.unit }; }); }); const t = m => m ? { hasChg: true, chg: `${md(m.d.slice(5))} 메모 · ${m.from != null ? fmt(m.from) + ' → ' : ''}${fmt(m.to)} ${m.unit || ''}` } : { hasChg: false, chg: '' }; return key => t(o[key]); }
  medVals() {
    const cur = this.state.med, sv = this.state.medSaved; const LC = this.lastChgOf('med');
    const r = v => Math.round(v * 10000) / 10000;
    const bump = (k, id, d) => this.setState(s => ({ med: { ...s.med, [k]: { ...s.med[k], [id]: Math.max(0, r(s.med[k][id] + d)) } } }));
    const CH = 'oklch(0.50 0.15 250)';
    const w = cur.w;
    const drafts = this.state.mDraft || {};
    const editable = (key, v, set) => ({ inputVal: drafts[key] != null ? drafts[key] : fmt(v),
      onFocus: e => { const el = e.target; setTimeout(() => { try { el.select(); } catch (x) {} }, 0); },
      onInput: e => { const raw = e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.'); this.setState(s => ({ mDraft: { ...(s.mDraft || {}), [key]: raw } })); const n = parseFloat(raw); if (raw !== '' && !isNaN(n) && n >= 0) set(r(n)); },
      onBlur: () => this.setState(s => { const d = { ...(s.mDraft || {}) }; delete d[key]; return { mDraft: d }; }) });
    const setM = (k, id) => n => this.setState(s => ({ med: { ...s.med, [k]: { ...s.med[k], [id]: n } } }));
    let lastG = null;
    const custom = cur.custom || [];
    const delC = id => this.setState(s => { const rx = { ...s.med.rx }, sup = { ...s.med.sup }; delete rx[id]; delete sup[id]; return { med: { ...s.med, rx, sup, custom: (s.med.custom || []).filter(c => c.id !== id) } }; });
    const hid = cur.hidden || [], ed = cur.edits || {}, mDel = this.state.mDel;
    const stepOf = d => d >= 10 ? 1 : d >= 1 ? 0.5 : d >= 0.1 ? 0.05 : 0.01;
    const ov = (m, kind) => { const e = !m.custom && ed[m.id]; if (!e) return m; const o = { ...m, name: e.name || m.name };
      if (e.unit && e.unit !== m.unit) { o.unit = e.unit; delete o.tabMg; o.uChg = true; }
      if (kind === 'rx') { if (e.freq != null) o.freq = e.freq || '–'; } else { if (e.freq != null) o.when = e.freq || '–'; if (e.noAmt) o.amt = null; else if (e.hasAmt && o.amt == null) { o.amt = 0; o.step = o.step || stepOf(cur.sup[m.id] || 0); } }
      return o; };
    const delM = m => this.setState(s => { if (s.mDel !== m.id) return { mDel: m.id };
      if (m.custom) { const rx = { ...s.med.rx }, sup = { ...s.med.sup }; delete rx[m.id]; delete sup[m.id]; return { mDel: null, med: { ...s.med, rx, sup, custom: (s.med.custom || []).filter(c => c.id !== m.id) } }; }
      return { mDel: null, med: { ...s.med, hidden: [...(s.med.hidden || []), m.id] } }; });
    if (!this._maRef) this._maRef = React.createRef();
    const editM = (kind, m, v, has) => { const f = kind === 'rx' ? m.freq : m.when; this.setState({ mDel: null, maErr: '', mAdd: { id: m.id, custom: !!m.custom, kind, name: m.name, dose: has ? fmt(v) : '', unit: m.unit || (kind === 'rx' ? 'mpk' : '알'), freq: f && f !== '–' ? f : '' } },
      () => setTimeout(() => { const el = this._maRef.current; if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 90, behavior: 'smooth' }); }, 30)); };
    const delUi = m => ({ del: () => { if (!window.confirm(`'${m.name}'을(를) 투약 목록에서 삭제할까요?`)) return; this.setState({ mDel: m.id }, () => delM(m)); } });
    const RXL0 = [...RX, ...custom.filter(c => c.kind === 'rx').map(c => ({ id: c.id, g: 9, name: c.name, dose: c.dose, step: c.step, unit: c.unit, freq: c.freq || '–', custom: true }))];
    const RXL = RXL0.filter(m => !hid.includes(m.id)).map(m => ov(m, 'rx'));
    const SUPL0 = [...SUP, ...custom.filter(c => c.kind === 'sup').map(c => ({ id: c.id, name: c.name, amt: c.dose, step: c.step, unit: c.unit, when: c.freq || '–', custom: true }))];
    const SUPL = SUPL0.filter(m => !hid.includes(m.id)).map(m => ov(m, 'sup'));
    const perOf = (m, v) => {
      const k = m.tabMg ? m.tabMg : (m.custom || m.uChg) && m.unit !== 'mpk' ? null : w;
      if (!k) return { perEd: false, perRo: true };
      const pu = m.tabMg ? 'mg' : m.unit === 'T/kg' ? 'T' : 'mg';
      return { perEd: true, perRo: false, perUnit: pu, perIn: editable('per:' + m.id, Math.round(v * k * 100) / 100, n => setM('rx', m.id)(r(n / k))) };
    };
    const rx = RXL.map(m => {
      const v = cur.rx[m.id] ?? 0, pv = sv.rx[m.id], ch = pv != null && Math.abs(v - pv) > 1e-9;
      const border = lastG !== null && lastG !== m.g ? '1.5px solid #EBCFC4' : '1px solid #F8E8E0'; lastG = m.g;
      return { ...LC('rx:' + m.id), name: m.name, text: `${fmt(v)} ${m.unit}`, prev: ch ? `${fmt(pv)}` : '', color: ch ? CH : '#4A3A33', freq: m.freq, per: m.tabMg ? `${fmt(Math.round(v * m.tabMg * 100) / 100)} mg` : (m.custom || m.uChg) && m.unit !== 'mpk' ? `${fmt(v)} ${m.unit}` : `${fmt(Math.round(v * w * 100) / 100)} ${m.unit === 'T/kg' ? 'T' : 'mg'}`, border, custom: !!m.custom, ...perOf(m, v), ...delUi(m), edit: () => editM('rx', m, v, true), unit: m.unit, ...editable('rx:' + m.id, v, setM('rx', m.id)),
        dec: () => bump('rx', m.id, -m.step), inc: () => bump('rx', m.id, m.step) };
    });
    const sup = SUPL.map(m => {
      const v = cur.sup[m.id] ?? 0, pv = sv.sup[m.id], has = m.amt != null, ch = has && pv != null && Math.abs(v - pv) > 1e-9;
      return { ...LC('sup:' + m.id), name: m.name, hasAmt: has, noAmt: !has, text: has ? `${fmt(v)} ${m.unit}` : '', prev: ch ? `${fmt(pv)}` : '', color: ch ? CH : '#4A3A33', when: m.when || '–', unit: m.unit || '', custom: !!m.custom, ...delUi(m), edit: () => editM('sup', m, v, has), ...(has ? editable('sup:' + m.id, v, setM('sup', m.id)) : {}),
        dec: () => bump('sup', m.id, -m.step), inc: () => bump('sup', m.id, m.step) };
    });
    const dirty = JSON.stringify(cur) !== JSON.stringify({ ...sv, at: cur.at });
    const at = sv.at ? new Date(sv.at) : null;
    const atText = at ? `${at.getMonth() + 1}.${String(at.getDate()).padStart(2, '0')} ${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}` : '';
    return {
      ...(() => {
        const ma = this.state.mAdd, setMa = p => this.setState(s => ({ mAdd: { ...s.mAdd, ...p }, maErr: '' }));
        const opt = (on, pick) => ({ pick, bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#6B5850', bd: on ? '#4A3A33' : '#F5DDD4' });
        if (!ma) return { maOpen: false, maRef: this._maRef, maOpenFn: () => this.setState({ mDel: null, mAdd: { kind: 'rx', name: '', dose: '', unit: 'mpk', freq: '' }, maErr: '' }) };
        const units = ma.kind === 'rx' ? ['mpk', 'mg', '알', '정', 'ml'] : ['알', 'mg', 'cc', 'ml', 'g'];
        if (ma.unit && !units.includes(ma.unit)) units.unshift(ma.unit);
        const isEd = !!ma.id;
        return { maOpen: true, maRef: this._maRef, maTitle: isEd ? '약물 수정' : '약물 추가', maShowKind: !isEd, maSubmitText: isEd ? '수정' : '추가', maHint: isEd ? '수정 후 아래 저장 버튼을 눌러야 최종 저장돼요.' : '추가 후 아래 저장 버튼을 눌러야 최종 저장돼요.', maOpenFn: () => this.setState({ mAdd: null }), maName: ma.name, maDose: ma.dose, maFreq: ma.freq, maErr: this.state.maErr || '',
          maFreqLabel: ma.kind === 'rx' ? '횟수' : '시간',
          maKRx: opt(ma.kind === 'rx', () => setMa({ kind: 'rx', unit: 'mpk' })), maKSup: opt(ma.kind === 'sup', () => setMa({ kind: 'sup', unit: '알' })),
          maUnits: units.map(u => ({ label: u, ...opt(ma.unit === u, () => setMa({ unit: u })) })),
          maOnName: e => setMa({ name: e.target.value }), maOnDose: e => setMa({ dose: e.target.value.replace(/[^0-9.,]/g, '').replace(',', '.') }), maOnFreq: e => setMa({ freq: e.target.value }),
          maCancel: () => this.setState({ mAdd: null, maErr: '' }),
          maSubmit: () => { const name = ma.name.trim(), d = parseFloat(ma.dose); if (!name) return this.setState({ maErr: '이름을 입력해주세요.' });
            if (isEd) { if (ma.dose.trim() !== '' && (isNaN(d) || d < 0)) return this.setState({ maErr: '용량을 숫자로 입력해주세요.' }); if (ma.kind === 'rx' && isNaN(d)) return this.setState({ maErr: '용량을 입력해주세요.' });
              const fr = ma.freq.trim();
              return this.setState(s => { const med = { ...s.med };
                if (ma.custom) med.custom = (med.custom || []).map(c => c.id === ma.id ? { ...c, name, unit: ma.unit, freq: fr, ...(isNaN(d) ? {} : { dose: d, step: c.step || stepOf(d) }) } : c);
                else med.edits = { ...(med.edits || {}), [ma.id]: { name, unit: ma.unit, freq: fr, ...(ma.kind === 'sup' ? (isNaN(d) ? { noAmt: true } : { hasAmt: true }) : {}) } };
                if (!isNaN(d)) med[ma.kind] = { ...med[ma.kind], [ma.id]: d };
                return { mAdd: null, maErr: '', med }; }); }
            if (isNaN(d) || d < 0) return this.setState({ maErr: '용량을 숫자로 입력해주세요.' });
            const id = 'c' + Date.now().toString(36), step = d >= 10 ? 1 : d >= 1 ? 0.5 : d >= 0.1 ? 0.05 : 0.01;
            this.setState(s => ({ mAdd: null, maErr: '', med: { ...s.med, custom: [...(s.med.custom || []), { id, kind: ma.kind, name, dose: d, step, unit: ma.unit, freq: ma.freq.trim() }], [ma.kind]: { ...s.med[ma.kind], [id]: d } } })); } };
      })(),
      wSrc: (() => { const l = latestBW(); return l ? (Math.abs(l.v - w) < 1e-9 ? `${md(l.d)} 측정 체중 자동 적용` : `최근 측정 ${fmt(l.v)} kg (${md(l.d)})`) : ''; })(),
      rx, sup, wIn: editable('w', w, n => this.setState(s => ({ med: { ...s.med, w: n } }))), wText: fmt(w), wColor: Math.abs(w - sv.w) > 1e-9 ? CH : '#4A3A33',
      wDec: () => this.setState(s => ({ med: { ...s.med, w: Math.max(0.5, r(s.med.w - 0.05)) } })),
      wInc: () => this.setState(s => ({ med: { ...s.med, w: r(s.med.w + 0.05) } })),
      saveStatus: dirty ? '저장되지 않은 변경 있음' : at ? `${atText} 저장됨` : '기본값',
      saveColor: dirty ? CH : '#A88F86', saveBg: dirty ? '#4A3A33' : '#A88F86',
      medSave: () => { const next = { ...this.state.med, at: Date.now() }; try { localStorage.setItem(MED_KEY, JSON.stringify(next)); } catch (e) {} this.setState({ med: next, medSaved: next }); },
      medRevert: () => this.setState(s => ({ med: s.medSaved })), medDirty: dirty, autoSaved: !!this.state.autoSavedAt,
    };
  }
  _autoSave(now) {
    const s = this.state, J = o => JSON.stringify({ ...o, at: 0 });
    const doMed = () => { const st = this.state; if (st.med === st.medSaved || J(st.med) === J(st.medSaved)) return; const next = { ...st.med, at: Date.now() }; try { localStorage.setItem(MED_KEY, JSON.stringify(next)); } catch (e) {} this.setState({ med: next, medSaved: next, autoSavedAt: Date.now() }); this._flashOff(); };
    const doDiet = () => { const st = this.state; if (st.diet === st.dietSaved || J(st.diet) === J(st.dietSaved)) return; const next = { ...st.diet, at: Date.now() }; try { localStorage.setItem(DIET_KEY2, JSON.stringify(next)); } catch (e) { this.setState({ dErr: '저장 공간이 부족해 저장하지 못했습니다. 이미지 수를 줄여주세요.' }); return; } this.setState({ diet: next, dietSaved: next, dErr: '', autoSavedAt: Date.now() }); this._flashOff(); };
    if (s.med !== s.medSaved) { clearTimeout(this._asM); if (now) doMed(); else this._asM = setTimeout(doMed, 500); }
    if (s.diet !== s.dietSaved) { clearTimeout(this._asD); if (now) doDiet(); else this._asD = setTimeout(doDiet, 500); }
  }
  _flashOff() { clearTimeout(this._asF); this._asF = setTimeout(() => this.setState({ autoSavedAt: 0 }), 1600); }
  _saveDraft(now) {
    const pick = {}; DRAFT_FIELDS.forEach(k => { pick[k] = this.state[k] === undefined ? null : this.state[k]; });
    const s = JSON.stringify(pick); if (s === this._draftLast) return;
    const write = () => { this._draftLast = s; try { localStorage.setItem(DRAFT_KEY, s); } catch (e) {} };
    clearTimeout(this._draftT); if (now) write(); else this._draftT = setTimeout(write, 400);
  }
  _afterUpdate() { if (!this._draftL) { this._draftL = true; const f = () => { this._autoSave(true); this._saveDraft(true); }; window.addEventListener('pagehide', f); document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') f(); }); } this._autoSave(); this._saveDraft(); this._bind && this._bind(); { const l = latestBW(), key = l ? l.d + ':' + l.v : ''; if (this._bwKey === undefined) this._bwKey = key; else if (key !== this._bwKey) { this._bwKey = key; if (l) this.setState(s => ({ med: { ...s.med, w: l.v }, medSaved: { ...s.medSaved, w: l.v } })); } } const lock = !!(this.state.labSheet || this.state.dEdit); if (lock !== this._locked) { this._locked = lock; document.documentElement.style.overflow = lock ? 'hidden' : ''; document.body.style.overflow = lock ? 'hidden' : ''; } }
  swipe(prev, next) {
    return { ts: e => { const p = e.touches[0]; this._tx = p.clientX; this._ty = p.clientY; }, te: e => { const p = e.changedTouches[0]; const dx = p.clientX - this._tx, dy = p.clientY - this._ty; if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2) { dx < 0 ? next() : prev(); } } };
  }
  xrayVals() {
    const IMG = window.IMAGING_DATA || {};
    const all = [];
    Object.keys(IMG).sort().forEach(k => IMG[k].forEach(it => { if (it[1] === 'xray') all.push({ d: k, src: it[0], t: it[2] }); }));
    const dims = this.state.dims;
    const loaders = !this.state.xReady ? [] : all.filter(x => dims[x.src] == null).map(x => ({ src: x.src, onLoad: e => { const im = e.target; const r = im.naturalWidth / im.naturalHeight; this.setState(s => ({ dims: { ...s.dims, [x.src]: r } })); } }));
    const pick = kind => {
      const sel = all.filter(x => { const r = dims[x.src]; if (r == null || r < 0) return false; return (r > 1.15 ? 'lat' : 'vd') === kind; });
      return sel.slice().sort((p, q) => p.d < q.d ? 1 : p.d > q.d ? -1 : 0).map((x, i) => ({ label: md(x.d), src: x.src, ref: srcRef(x.src), open: () => this.setState({ xlb: { k: kind, i } }) }));
    };
    const xlb = this.state.xlb;
    const lat = pick('lat'), vd = pick('vd');
    const xs = xlb && typeof xlb === 'object' ? (xlb.k === 'lat' ? lat : vd) : null;
    const xc = xs && xs[xlb.i];
    const xgo = n => e => { if (e) e.stopPropagation(); if (!xs || !xs.length) return; this.setState({ xlb: { k: xlb.k, i: (xlb.i + n + xs.length) % xs.length } }); };
    const xv = xc ? { open: true, caption: `${xc.label} · ${xlb.k === 'lat' ? '측면' : '복배·배복'} ${xlb.i + 1}/${xs.length}`, close: () => this.setState({ xlb: null }), prev: xgo(-1), next: xgo(1), stop: e => e.stopPropagation(), ...this.swipe(xgo(-1), xgo(1)) } : { open: false };
    return { xLoaderEls: loaders.map(l => React.createElement('img', { key: l.src, src: l.src, onLoad: l.onLoad, onError: () => this.setState(s => ({ dims: { ...s.dims, [l.src]: -1 } })), alt: '' })), xLat: lat, xVd: vd, xLoading: loaders.length > 0, xv, xvImg: xc ? React.createElement('img', { key: xc.src, src: xc.src, alt: '확대 X-ray', style: { maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', userSelect: 'none' } }) : null };
  }
  mountGallery() {
    if (!window.IMAGING_DATA) { this._poll = setInterval(() => { if (window.IMAGING_DATA) { clearInterval(this._poll); this.forceUpdate(); } }, 200); }
    this._key = e => {
      if (this.state.lb == null) return;
      if (e.key === 'Escape') this.setState({ lb: null });
      if (e.key === 'ArrowRight') this.step(1);
      if (e.key === 'ArrowLeft') this.step(-1);
    };
    window.addEventListener('keydown', this._key);
  }
  unmountGallery() { clearInterval(this._poll); window.removeEventListener('keydown', this._key); }
  step(n) {
    const list = (window.IMAGING_DATA || {})[this.state.sel] || [];
    if (!list.length) return;
    this.setState(s => ({ lb: (s.lb + n + list.length) % list.length }));
  }
  galleryVals() {
    const IMG = window.IMAGING_DATA || {};
    const bloodDates = DATA.flatMap(sec => sec.items.flatMap(s => s.pts.map(p => p.d)));
    const LMEMO = {}; (this.state.memos || []).forEach(m => { if (!m.auto && m.d && m.d.startsWith('2026-') && ((m.labs || []).length || m.kind === 'lab')) (LMEMO[m.d.slice(5)] = LMEMO[m.d.slice(5)] || []).push(m); });
    const keys = [...new Set([...Object.keys(IMG), ...bloodDates, ...Object.keys(NOTES), ...Object.keys(LMEMO)])].sort();
    const sel = this.state.sel && keys.includes(this.state.sel) ? this.state.sel : keys[keys.length - 1];
    const imgDates = [...keys].reverse().map(k => {
      const on = k === sel;
      return { label: md(k), count: (IMG[k] || []).length, bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#4A3A33', border: on ? '#4A3A33' : '#F5DDD4', onClick: () => this.setState({ sel: k, lb: null }) };
    });
    const list = IMG[sel] || [];
    const blood = [];
    DATA.forEach(sec => sec.items.forEach(s => {
      const p = s.pts.find(q => q.d === sel); if (!p) return;
      const st = status(p.v, s);
      blood.push({ abbr: s.abbr, text: fmt(p.v), mark: st === 'hi' ? '↑' : st === 'lo' ? '↓' : '',
        bg: st === 'hi' ? 'oklch(0.94 0.04 28)' : st === 'lo' ? 'oklch(0.94 0.03 250)' : '#FFF0E8',
        fg: st === 'hi' ? 'oklch(0.42 0.16 28)' : st === 'lo' ? 'oklch(0.40 0.14 250)' : '#4A3A33',
        tip: `${s.name} ${fmt(p.v)} ${s.unit}${s.lo != null ? ` (참고 ${s.lo}–${s.hi})` : ''}` });
    }));
    const notes = [...(LMEMO[sel] || []).map(m => ({ text: m.text || `${m.target || ''} ${m.name || ''}`, kind: '메모' })), ...(NOTES[sel] || []).map(t => ({ text: t, kind: '기록' })), ...(IMG_NOTES[sel] || []).map(t => ({ text: t, kind: '영상' }))];
    if ((IMG[sel] || []).length && !IMG_NOTES[sel]) notes.push({ kind: '영상', text: '이 날 영상의 판독 소견을 담당 수의사에게 받아 두기' });
    DATA.forEach(sec => sec.items.forEach(s => {
      const i = s.pts.findIndex(q => q.d === sel); if (i < 0) return;
      const p = s.pts[i], prev = s.pts[i - 1];
      const st = status(p.v, s);
      if (st !== 'ok') {
        const span = (s.hi - s.lo) || 1;
        const dev = st === 'hi' ? (p.v - s.hi) / span : (s.lo - p.v) / span;
        if (dev > 0.5) notes.push({ kind: '범위', text: `${s.abbr} ${fmt(p.v)} ${s.unit} — 참고범위(${s.lo}–${s.hi})보다 크게 ${st === 'hi' ? '높음' : '낮음'}` });
      }
      if (prev && prev.v) {
        const ch = (p.v - prev.v) / Math.abs(prev.v);
        if (Math.abs(ch) >= 0.3) notes.push({ kind: '변화', text: `${s.abbr} 직전(${md(prev.d)}) ${fmt(prev.v)} → ${fmt(p.v)} · ${ch > 0 ? '+' : ''}${Math.round(ch * 100)}%` });
      }
    }));
    notes.forEach(n => { n.color = n.kind === '메모' ? 'oklch(0.45 0.15 28)' : n.kind === '범위' ? 'oklch(0.48 0.16 28)' : n.kind === '변화' ? 'oklch(0.45 0.12 70)' : n.kind === '영상' ? 'oklch(0.45 0.12 250)' : '#6B5850'; });
    const echo = ECHO[sel] || [];
    const groups = [];
    list.forEach((it, i) => {
      let g = groups.find(x => x.type === it[1]);
      if (!g) { g = { type: it[1], label: TYPE_LABEL[it[1]] || it[1], imgs: [] }; groups.push(g); }
      g.imgs.push({ src: it[0], ref: srcRef(it[0]), t: it[2] || '', alt: `${md(sel)} ${g.label}`, open: () => this.setState({ lb: i }) });
    });
    groups.forEach(g => { g.count = g.imgs.length; });
    const cnt = t => list.filter(x => x[1] === t).length;
    const parts = [cnt('xray') && `X-ray ${cnt('xray')}장`, cnt('us') && `초음파 ${cnt('us')}장`, cnt('etc') && `기타 ${cnt('etc')}장`, cnt('report') && `보고서 ${cnt('report')}장`].filter(Boolean);
    const li = this.state.lb;
    const lb = li != null && list[li]
      ? { open: true, src: list[li][0], caption: `${md(sel)} · ${TYPE_LABEL[list[li][1]]} ${li + 1}/${list.length}`, close: () => this.setState({ lb: null }), prev: e => { e.stopPropagation(); this.step(-1); }, next: e => { e.stopPropagation(); this.step(1); }, stop: e => e.stopPropagation(), ...this.swipe(() => this.step(-1), () => this.step(1)) }
      : { open: false };
    this.dateRowRef = this.dateRowRef || React.createRef();
    const dScroll = n => () => { const el = this.dateRowRef.current; if (el) { el.style.scrollSnapType = 'none'; el.scrollLeft += n * Math.max(160, el.clientWidth * 0.7); setTimeout(() => { el.style.scrollSnapType = ''; }, 50); } };
    const dDown = e => { const el = this.dateRowRef.current; if (!el || e.button !== 0) return; const x0 = e.clientX, s0 = el.scrollLeft; this._dMoved = false; el.style.scrollSnapType = 'none';
      const mv = ev => { const dx = ev.clientX - x0; if (Math.abs(dx) > 5) this._dMoved = true; el.scrollLeft = s0 - dx; ev.preventDefault(); };
      const up = () => { window.removeEventListener('mousemove', mv); window.removeEventListener('mouseup', up); el.style.scrollSnapType = ''; };
      window.addEventListener('mousemove', mv); window.addEventListener('mouseup', up); e.preventDefault(); };
    const dClickCap = e => { if (this._dMoved) { e.stopPropagation(); e.preventDefault(); this._dMoved = false; } };
    return { imgDates, dateRowRef: this.dateRowRef, dDown, dClickCap, dateL: dScroll(-1), dateR: dScroll(1), lb, lbImg: lb.open ? React.createElement('img', { key: lb.src, src: lb.src, alt: '확대 이미지', style: { maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: 4, userSelect: 'none' } }) : null, sel: { label: md(sel || ''), summary: parts.length ? parts.join(' · ') : '영상 없음', notes, hasNotes: notes.length > 0, hasImgs: list.length > 0, blood, hasBlood: blood.length > 0, noBlood: blood.length === 0, echo, hasEcho: echo.length > 0, groups } };
  }
  memoOptions() {
    const cur = this.state.med || {}, ed = cur.edits || {}, hid = cur.hidden || [], custom = cur.custom || [];
    const meds = [];
    [...RX, ...custom.filter(c => c.kind === 'rx').map(c => ({ ...c, custom: true }))].forEach(m => {
      if (hid.includes(m.id)) return; const e = !m.custom && ed[m.id]; const unit = (e && e.unit) || m.unit;
      meds.push({ kind: 'med', id: m.id, key: 'rx:' + m.id, name: (e && e.name) || m.name, unit, tabMg: unit === m.unit ? m.tabMg : null, v: (cur.rx || {})[m.id] ?? 0 });
    });
    [...SUP, ...custom.filter(c => c.kind === 'sup').map(c => ({ ...c, amt: c.dose, custom: true }))].forEach(m => {
      if (hid.includes(m.id)) return; const e = !m.custom && ed[m.id];
      const has = e && e.noAmt ? false : e && e.hasAmt ? true : m.amt != null; if (!has) return;
      meds.push({ kind: 'med', id: m.id, key: 'sup:' + m.id, name: (e && e.name) || m.name, unit: (e && e.unit) || m.unit || '', v: (cur.sup || {})[m.id] ?? 0 });
    });
    const dt = this.state.diet || { foods: [], amt: {} };
    const foods = dt.foods.map(f => ({ kind: 'diet', id: f.id, key: f.id, name: f.name || '이름 없음', unit: f.unit, v: (dt.amt || {})[f.id] ?? 0 }));
    return { meds, foods, w: cur.w || 4 };
  }
  // 메모 글에서 약·음식 이름과 바뀐 양을 찾아냄
  parseMemo(text) {
    const src = String(text || ''); if (!src.trim()) return { changes: [], labs: [], notes: [] };
    const o = this.memoOptions(), items = [...o.meds, ...o.foods];
    const EXTRA = { pimo: ['피모'], gaba: ['가바'], amlo: ['암로'], irbe: ['이르베'], sily: ['실리마린'], udca: ['우르소', '우루사', 'udca'], lepo: ['레포틸'], meto: ['메토', '맥페란'], famo: ['파모'], ondan: ['온단', '온다'], maro: ['세레니아', '마로'], samsca: ['삼스카', '톨밥탄', '톨바프탄'], fet: ['훼르', '훼르콥'], fuco: ['후코'], probio: ['유산균'], renamezin: ['레나메진'], renadil: ['레나딜'], fosrenol: ['포스레놀'], renvela: ['렌벨라'], antares: ['안타레스'], activate: ['액티베이트'],
      rcdry: ['건사료', '레날 스몰독', '레날스몰독', '스몰독'], rice: ['저단백밥', '햇반'], yume: ['유메고항', '유메'], ringer: ['링거독'], renal: ['레날 리퀴드', '레날리퀴드', '리퀴드'], water: ['물'] };
    const cand = [];
    items.forEach(it => {
      const set = new Set();
      const n = it.name.trim(); set.add(n); set.add(n.replace(/\s*\(.*?\)\s*/g, ' ').replace(/\s+/g, ' ').trim()); set.add(n.replace(/\s+/g, ''));
      const base = n.replace(/\s*\(.*?\)\s*/g, ' ').replace(/\s+\d.*$/, '').trim(); if (base.length >= 2) set.add(base);
      (EXTRA[it.id] || []).forEach(a => set.add(a));
      set.forEach(a => { if (a) cand.push({ a: a.toLowerCase(), it }); });
    });
    const owners = {}; cand.forEach(c => { (owners[c.a] = owners[c.a] || new Set()).add(c.it.key); });
    const aliases = cand.filter(c => owners[c.a].size === 1).sort((x, y) => y.a.length - x.a.length);
    const low = src.toLowerCase(), taken = new Array(low.length).fill(false), hits = [];
    aliases.forEach(({ a, it }) => {
      let i = low.indexOf(a);
      while (i >= 0) {
        const end = i + a.length, prevC = low[i - 1] || ' ', nextC = low[end] || ' ';
        const short = a.length < 2;
        const okShort = !short || (/[\s,.(]|^$/.test(prevC) || i === 0) && /\s*\d/.test(low.slice(end, end + 3));
        const latinEdge = /[a-z]/.test(a[0]) ? !/[a-z]/.test(prevC) && !/[a-z]/.test(nextC) : true;
        if (okShort && latinEdge && !taken.slice(i, end).some(Boolean)) { for (let k = i; k < end; k++) taken[k] = true; hits.push({ i, end, it }); }
        i = low.indexOf(a, end);
      }
    });
    hits.sort((x, y) => x.i - y.i);
    const U = u => { u = (u || '').toLowerCase().replace(/\s/g, ''); if (u === 'mg/kg') return 'mpk'; if (u === 'cc') return 'ml'; if (u === '정' || u === 't' || u === '알' || u === '캡슐') return '알'; return u; };
    const r4 = v => Math.round(v * 10000) / 10000;
    const changes = [], notes = [], seen = new Set();
    hits.forEach((h, idx) => {
      const stop = idx + 1 < hits.length ? hits[idx + 1].i : low.length;
      let clause = src.slice(h.end, stop); const cut = clause.search(/[\n.!?;]\s|[\n!?;]|。|\.$/); if (cut >= 0) clause = clause.slice(0, cut);
      clause = clause.slice(0, 48);
      const it = h.it; if (seen.has(it.key)) return;
      let to = null;
      if (/(중단|끊|스톱|stop|빼기로|뺌|뺐|제외|안\s?먹|그만)/i.test(clause)) to = 0;
      else {
        const nums = []; const re = /(\d+(?:\.\d+)?|\.\d+)\s*(mg\/kg|mpk|mg|ml|cc|g|알|정|캡슐|t\b|포)?(\s*(일|시|월|회|번|kg|주|개월|분|%|kcal|살))?/gi; let m;
        while ((m = re.exec(clause))) { if (m[3]) continue; const before = clause.slice(Math.max(0, m.index - 1), m.index); if (/[\/:]/.test(before)) continue; nums.push({ v: parseFloat(m[1]), u: m[2] || '', at: m.index, end: m.index + m[0].length }); }
        let pick = null;
        if (nums.length) {
          const toMark = nums.find(n => /^\s*(으로|로)/.test(clause.slice(n.end)));
          if (toMark) pick = toMark;
          else if (/(→|->|에서|＞|>)/.test(clause) && nums.length >= 2) pick = nums[nums.length - 1];
          else pick = nums[0];
          const relUp = /(만큼|씩)\s*(올|늘|증량|추가)/.test(clause.slice(pick.end)) || /^\s*(더|추가)/.test(clause.slice(pick.end));
          const relDown = /(만큼|씩)\s*(내|줄|감량|빼)/.test(clause.slice(pick.end));
          let v = pick.v, u = U(pick.u), iu = U(it.unit);
          if (u && u !== iu) {
            if (it.kind === 'med' && iu === 'mpk' && u === 'mg') v = v / o.w;
            else if (it.kind === 'med' && it.tabMg && u === 'mg') v = v / it.tabMg;
            else if (it.kind === 'med' && iu === 'mg' && u === 'mpk') v = v * o.w;
            else { notes.push(`${it.name}: '${pick.v}${pick.u}' 단위가 ${it.unit}와 달라서 반영하지 않았어요`); seen.add(it.key); return; }
          }
          to = relUp ? it.v + v : relDown ? Math.max(0, it.v - v) : v;
        } else if (/(반으로|절반)/.test(clause)) to = it.v / 2;
        else if (/(두\s?배|2배)/.test(clause)) to = it.v * 2;
      }
      if (to == null) return;
      to = r4(to); seen.add(it.key);
      if (Math.abs(to - it.v) < 1e-9) { notes.push(`${it.name}은(는) 이미 ${fmt(to)} ${it.unit}이에요`); return; }
      changes.push({ kind: it.kind, target: it.key, name: it.name, unit: it.unit, from: it.v, to });
    });
    const labs = [];
    DATA.forEach((sec, si) => sec.items.forEach(s => {
      const ab = s.abbr.replace(/[⁺⁻]/g, '').toLowerCase();
      const hitAb = ab.length >= 2 && new RegExp('(^|[^a-z])' + ab.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z]|$)', 'i').test(src);
      const nm = s.name.replace(/\s*\(.*?\)/, ''); const hitNm = nm.length >= 3 && src.includes(nm);
      if (hitAb || hitNm) labs.push({ abbr: s.abbr, name: s.name, si });
    }));
    return { changes, labs, notes };
  }
  applyChanges(list, useFrom) {
    if (!list.length) return;
    this.setState(s => {
      let med = s.med, medSaved = s.medSaved, diet = s.diet, dietSaved = s.dietSaved, mT = false, dT = false;
      list.forEach(c => { const v = useFrom ? c.from : c.to;
        if (c.kind === 'med') { const [k, id] = c.target.split(':'); med = { ...med, [k]: { ...med[k], [id]: v } }; medSaved = { ...medSaved, [k]: { ...medSaved[k], [id]: v } }; mT = true; }
        else { diet = { ...diet, amt: { ...diet.amt, [c.target]: v } }; dietSaved = { ...dietSaved, amt: { ...dietSaved.amt, [c.target]: v } }; dT = true; } });
      if (mT) { medSaved = { ...medSaved, at: Date.now() }; try { localStorage.setItem(MED_KEY, JSON.stringify(medSaved)); } catch (e) {} }
      if (dT) { dietSaved = { ...dietSaved, at: Date.now() }; try { localStorage.setItem(DIET_KEY2, JSON.stringify(dietSaved)); } catch (e) {} }
      return { med, medSaved, diet, dietSaved };
    });
  }
  curValOf(c) { if (c.kind === 'med') { const [k, id] = c.target.split(':'); return ((this.state.medSaved || {})[k] || {})[id]; } return ((this.state.dietSaved || {}).amt || {})[c.target]; }
  memoVals() {
    const list = (this.state.memos || []).filter(m => !m.auto && (m.text || '').trim());
    const allList = this.state.memos || [];
    const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
    const blank = () => ({ d: today(), text: '', id: null });
    const dr = { ...blank(), ...(this.state.memoDraft || {}) };
    const save = next => { try { localStorage.setItem(MEMO_KEY, JSON.stringify(next)); } catch (e) {} this.setState({ memos: next }); };
    const setDr = p => this.setState(s => ({ memoDraft: { ...blank(), ...(s.memoDraft || {}), ...p } }));
    const W = ['일', '월', '화', '수', '목', '금', '토'];
    const MED_C = { fg: 'oklch(0.42 0.12 250)', bg: 'oklch(0.95 0.03 250)', icon: '💊' }, DIET_C = { fg: 'oklch(0.40 0.10 150)', bg: 'oklch(0.95 0.04 150)', icon: '🍚' };
    const chText = c => `${c.name} ${fmt(c.from)} → ${fmt(c.to)} ${c.unit}`.trim();
    // 작성 중 미리보기
    const old = dr.id ? allList.find(m => m.id === dr.id) : null;
    const pv = this.parseMemo(dr.text);
    const prevApplied = old ? (old.applied || []).filter(c => !c.undone) : [];
    const pvChanges = pv.changes.filter(c => !prevApplied.some(p => p.target === c.target && Math.abs(p.to - c.to) < 1e-9));
    const preview = pvChanges.map(c => { const C = c.kind === 'med' ? MED_C : DIET_C; return { text: `${C.icon} ${chText(c)}`, fg: C.fg, bg: C.bg }; });
    const submit = () => {
      const t = dr.text.trim(); if (!t) return;
      let applied = [];
      if (old) {
        const keep = prevApplied.filter(p => pv.changes.some(c => c.target === p.target && Math.abs(c.to - p.to) < 1e-9));
        const revert = prevApplied.filter(p => !keep.includes(p) && Math.abs((this.curValOf(p) ?? NaN) - p.to) < 1e-9);
        this.applyChanges(revert, true);
        applied = [...keep];
      }
      const fresh = old ? pvChanges : pv.changes;
      this.applyChanges(fresh);
      applied = [...applied, ...fresh];
      const labs = pv.labs.map(l => ({ abbr: l.abbr, name: l.name }));
      const next = old ? allList.map(m => m.id === old.id ? { ...m, text: t, d: dr.d, applied, labs, kind: undefined } : m) : [...allList, { id: 'm' + Date.now().toString(36), d: dr.d, text: t, done: false, at: Date.now(), applied, labs }];
      save(next);
      const msg = fresh.length ? `${fresh.map(chText).join(', ')} — ${[fresh.some(c => c.kind === 'med') && '투약', fresh.some(c => c.kind === 'diet') && '식단'].filter(Boolean).join('·')} 탭에 반영했어요.` : '메모를 저장했어요.';
      this.setState({ memoDraft: { ...blank(), d: dr.d }, memoForm: false, memoFlash: msg });
      clearTimeout(this._mfT); this._mfT = setTimeout(() => this.setState({ memoFlash: '' }), 4000);
    };
    // 타임라인 (직접 쓴 메모만)
    const sorted = [...list].sort((a, b) => b.d.localeCompare(a.d) || (b.at || 0) - (a.at || 0));
    const mk = m => {
      const legacy = m.kind && m.kind !== 'note' && m.to != null && !m.applied ? [{ kind: m.kind, target: m.target, name: m.name, unit: m.unit, from: m.from, to: m.to }] : [];
      const ap = (m.applied || legacy);
      const changes = ap.map((c, i) => { const C = c.kind === 'med' ? MED_C : DIET_C; const live = !c.undone && Math.abs((this.curValOf(c) ?? NaN) - c.to) < 1e-9;
        const st = c.undone ? '되돌림' : live ? '반영됨' : '이후 변경됨'; return { text: `${C.icon} ${chText(c)}`, icon: C.icon, name: c.name, from: fmt(c.from), to: fmt(c.to), unit: c.unit || '', sep: i ? '#F8E8E0' : 'transparent', fg: c.undone ? '#BFA49A' : C.fg, bg: c.undone ? '#FFF6EF' : C.bg, deco: 'none', state: st, stBg: c.undone ? '#F3ECE8' : live ? C.bg : '#FFF0E8', stFg: c.undone ? '#A88F86' : live ? C.fg : '#9A7F74', canUndo: live && !!m.applied, canRedo: !!c.undone,
          undo: () => { this.applyChanges([c], true); save(allList.map(x => x.id === m.id ? { ...x, applied: x.applied.map((y, j) => j === i ? { ...y, undone: true } : y) } : x)); },
          redo: () => { const cur = this.curValOf(c); const c2 = { ...c, from: cur ?? c.from, undone: false }; this.applyChanges([c2]); save(allList.map(x => x.id === m.id ? { ...x, applied: x.applied.map((y, j) => j === i ? c2 : y) } : x)); },
          go: () => { this.setState({ tab: c.kind === 'med' ? 'meds' : 'diet' }); window.scrollTo({ top: 0, behavior: 'smooth' }); } }; });
      const labs = (m.labs || (m.kind === 'lab' && m.target ? [{ abbr: m.target, name: m.name }] : [])).map(l => { const si = DATA.findIndex(sec => sec.items.some(s => s.abbr === l.abbr));
        return { label: `${l.abbr} 그래프 ›`, go: () => { if (si < 0) return; this.setState({ tab: 'labs', mFilter: 'g' + si, mOpen: si + ':' + l.abbr }, () => setTimeout(() => { const el = this._mChipEl; if (el) window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 70, behavior: 'smooth' }); }, 80)); } }; });
      return { text: m.text, changes, hasChanges: changes.length > 0, labs, hasLabs: labs.length > 0, dot: changes.some(c => c.text.startsWith('💊')) ? 'oklch(0.74 0.10 250)' : changes.length ? 'oklch(0.76 0.11 150)' : labs.length ? 'oklch(0.74 0.12 28)' : '#E3C9BE',
        time: m.at ? (() => { const t = new Date(m.at); return `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`; })() : '',
        tags: [...(ap.some(c => c.kind === 'med') ? [{ label: '💊 약 용량', bg: MED_C.bg, fg: MED_C.fg }] : []), ...(ap.some(c => c.kind === 'diet') ? [{ label: '🍚 식단', bg: DIET_C.bg, fg: DIET_C.fg }] : []), ...(labs.length ? [{ label: '🩺 검사', bg: 'oklch(0.96 0.03 28)', fg: 'oklch(0.45 0.15 28)' }] : [])],
        edit: () => { this.setState({ memoDraft: { d: m.d, text: m.text || '', id: m.id }, memoForm: true }); window.scrollTo({ top: 0, behavior: 'smooth' }); },
        del: () => { const live = (m.applied || []).filter(c => !c.undone && Math.abs((this.curValOf(c) ?? NaN) - c.to) < 1e-9);
          if (live.length && window.confirm(`이 메모로 바뀐 ${live.map(c => c.name).join(', ')}도 원래대로 되돌릴까요?\n확인: 되돌리고 삭제 · 취소: 용량은 그대로 두고 삭제`)) this.applyChanges(live, true);
          save(allList.filter(x => x.id !== m.id)); } };
    };
    const months = [];
    sorted.forEach(m => {
      const ym = m.d.slice(0, 7); let M = months[months.length - 1];
      if (!M || M.ym !== ym) { M = { ym, label: `${+ym.slice(0, 4)}년 ${+ym.slice(5, 7)}월`, days: [] }; months.push(M); }
      let D = M.days[M.days.length - 1];
      if (!D || D.d !== m.d) { const [y, mo, da] = m.d.split('-').map(Number); const isT = m.d === today(); D = { d: m.d, title: `${mo}월 ${da}일 ${W[new Date(y, mo - 1, da).getDay()]}요일`, isToday: isT, items: [] }; M.days.push(D); }
      D.items.push(mk(m));
    });
    months.forEach(M => M.days.forEach(D => D.items.forEach((x, i) => { x.railOp = i === D.items.length - 1 ? '0' : '1'; })));
    const formOpen = !!this.state.memoForm || !!dr.id;
    return {
      memoText: dr.text, memoDate: dr.d,
      memoOnText: e => setDr({ text: e.target.value }), memoOnDate: e => setDr({ d: e.target.value || today() }),
      memoPreview: preview, memoHasPreview: preview.length > 0, memoPvNotes: pv.notes.map(t => ({ t })), memoHasPvNotes: pv.notes.length > 0,
      memoBtnText: dr.id ? '수정 저장' : preview.length ? '저장하고 반영' : '저장', memoBtnBg: dr.text.trim() ? '#4A3A33' : '#CDB5AB',
      memoFormOpen: formOpen, memoAddText: formOpen ? '닫기' : '＋ 메모', memoAddBg: formOpen ? '#FFF0E8' : '#4A3A33', memoAddFg: formOpen ? '#6B5850' : '#FFFFFF',
      memoOpenToggle: () => formOpen ? this.setState({ memoForm: false, memoDraft: blank() }) : this.setState({ memoForm: true }),
      memoSubmit: submit, memoEditing: !!dr.id, memoCancel: () => this.setState({ memoDraft: blank(), memoForm: false }),
      memoFlash: this.state.memoFlash || '', memoHasFlash: !!this.state.memoFlash,
      memoHas: months.length > 0, memoEmpty: months.length === 0, memoCountText: list.length ? `메모 ${list.length}개` : '', memoMonths: months,
    };
  }
  mobVals() {
    const f = this.state.mFilter || 'all', open = this.state.mOpen;
    const showBand = this.props.showBand ?? true, byHosp = (this.props.pointColor ?? '수치 상태') === '병원별';
    let hi = 0, lo = 0, ok = 0, ld = '';
    const all = [];
    DATA.forEach((sec, si) => sec.items.forEach(s => {
      const n = s.pts.length; if (!n) return;
      const last = s.pts[n - 1], prev = n > 1 ? s.pts[n - 2] : null, st = status(last.v, s);
      if (st === 'hi') hi++; else if (st === 'lo') lo++; else ok++;
      if (last.d > ld) ld = last.d;
      all.push({ si, s, last, prev, st });
    }));
    const tint = { hi: ['oklch(0.94 0.04 28)', 'oklch(0.42 0.16 28)', '↑'], lo: ['oklch(0.94 0.03 250)', 'oklch(0.40 0.14 250)', '↓'], ok: ['transparent', '#4A3A33', ''] };
    const shown = all.filter(it => f === 'all' || (f === 'hi' || f === 'lo' ? it.st === f : f === 'flag' ? it.st !== 'ok' : f === 'g' + it.si));
    const pick = k => () => this.setState(s => ({ mFilter: s.mFilter === k ? 'all' : k, mOpen: null }));
    const mGroups = DATA.map((sec, si) => ({ title: sec.title, items: shown.filter(it => it.si === si).map(it => {
      const { s, last, prev, st } = it, key = si + ':' + s.abbr, isOpen = open === key;
      let a = s.pts[0], b = s.pts[0]; s.pts.forEach(p => { if (p.v > a.v) a = p; if (p.v < b.v) b = p; });
      const dv = prev ? Math.round((last.v - prev.v) * 100) / 100 : null;
      return {
        abbr: s.abbr, name: s.name, unit: s.unit, range: s.lo != null ? `${s.lo}–${s.hi}` : '–',
        val: fmt(last.v), bg: tint[st][0], fg: tint[st][1], mark: tint[st][2],
        delta: md(last.d) + (dv == null ? '' : dv === 0 ? ' · 변화 없음' : ` · ${dv > 0 ? '▲' : '▼'}${fmt(Math.abs(dv))}`),
        spark: React.createElement(Spark, { s }),
        open: isOpen, toggle: () => this.setState({ mOpen: isOpen ? null : key }),
        chart: isOpen ? React.createElement(Chart, { s, showBand, byHosp }) : null,
        hist: isOpen ? [...s.pts].reverse().map(p => ({ d: md(p.d), h: HOSP[p.h] || '', v: fmt(p.v) + ' ' + s.unit, color: C[status(p.v, s)] })) : [],
        maxText: `${fmt(a.v)} (${md(a.d)})`, minText: `${fmt(b.v)} (${md(b.d)})`, count: s.pts.length,
      };
    }) })).filter(g => g.items.length);
    const chipDefs = [['all', '전체'], ['flag', '이상 수치만'], ...DATA.map((sec, i) => ['g' + i, sec.title])];
    const curIdx = Math.max(0, chipDefs.findIndex(([k]) => k === (f === 'hi' || f === 'lo' ? 'flag' : f)));
    const mSwTs = e => { const t = e.touches[0]; this._msw = { x: t.clientX, y: t.clientY, t: Date.now() }; };
    const mSwTe = e => { const s0 = this._msw; this._msw = null; if (!s0) return; const t = e.changedTouches[0], dx = t.clientX - s0.x, dy = t.clientY - s0.y;
      if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.5 || Date.now() - s0.t > 800) return;
      const ni = curIdx + (dx < 0 ? 1 : -1); if (ni < 0 || ni >= chipDefs.length) return;
      this.setState({ mFilter: chipDefs[ni][0], mOpen: null }, () => { const bar = this._chipEl; const b = bar && bar.children[ni]; if (b) bar.scrollTo({ left: b.offsetLeft - (bar.clientWidth - b.offsetWidth) / 2, behavior: 'smooth' }); }); };
    const mChips = chipDefs.map(([k, label]) => { const on = f === k || (k === 'flag' && (f === 'hi' || f === 'lo')); return { label, bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#6B5850', bd: on ? '#4A3A33' : '#F5DDD4', pick: () => this.setState({ mFilter: k, mOpen: null }) }; });
    const HS = { S: '심장', J: '지중해', B: '비엔', P: '부평' };
    const devOf = it => { const { s, last, st } = it; const span = (s.hi - s.lo) || 1; return st === 'hi' ? (last.v - s.hi) / span : (s.lo - last.v) / span; };
    const cut = ld ? toT(ld) - 14 * 864e5 : 0;
    const recent = all.filter(it => toT(it.last.d) >= cut);
    const fromD = recent.reduce((m, it) => it.last.d < m ? it.last.d : m, ld);
    const mFlags = recent.filter(it => it.st !== 'ok' && it.s.lo != null).sort((a, b) => devOf(b) - devOf(a)).map(it => ({
      abbr: it.s.abbr, name: it.s.name, val: fmt(it.last.v), mark: it.st === 'hi' ? '↑' : '↓', unit: it.s.unit,
      cmp: it.prev ? (() => { const dv = Math.round((it.last.v - it.prev.v) * 100) / 100; return `직전 ${md(it.prev.d)} ${fmt(it.prev.v)} → ${fmt(it.last.v)} · ${dv === 0 ? '변화 없음' : (dv > 0 ? '▲' : '▼') + fmt(Math.abs(dv))}`; })() : '직전 기록 없음',
      range: `${it.s.lo}–${it.s.hi}`, date: md(it.last.d), label: it.st === 'hi' ? (devOf(it) > 0.5 ? '많이 높음' : '높음') : (devOf(it) > 0.5 ? '많이 낮음' : '낮음'),
      color: it.st === 'hi' ? 'oklch(0.80 0.10 28)' : 'oklch(0.80 0.09 250)',
      go: () => this.setState({ mFilter: 'g' + it.si, mOpen: it.si + ':' + it.s.abbr }),
    }));
    const FG = [[0, '신장'], [2, '빈혈 · 혈구'], [1, '나트륨 · 전해질'], [3, '간 · 염증']];
    const fgOrder = [...FG, ...DATA.map((sec, i) => [i, sec.title]).filter(([i]) => !FG.some(g => g[0] === i))];
    const flagSi = recent.filter(it => it.st !== 'ok' && it.s.lo != null);
    const mFlagGroups = fgOrder.map(([si, title]) => ({ title, items: mFlags.filter((x, k) => flagSi.find(it => it.s.abbr === x.abbr && it.si === si)) })).filter(g => g.items.length);
    const allD = [...new Set(DATA.flatMap(sec => sec.items.flatMap(s => s.pts.map(p => p.d))))].sort().reverse();
    const selD = allD.includes(this.state.mDate) ? this.state.mDate : allD[0];
    const di = allD.indexOf(selD);
    const goD = d => this.setState({ mDate: d });
    let pmo = '';
    const dvDates = allD.map(d => { const m = +d.split('-')[0], on = d === selD, ml = m + '' !== pmo ? m + '월' : ' '; pmo = m + ''; return { month: ml, day: +d.split('-')[1], hosp: d === '05-05' ? '비엔·부평' : HS[DMAP[d] || 'P'], bg: on ? '#4A3A33' : '#FFFFFF', fg: on ? '#FFFFFF' : '#4A3A33', bd: on ? '#4A3A33' : '#F5DDD4', pick: () => goD(d) }; });
    let dvHi = 0, dvLo = 0, dvOk = 0, dvN = 0;
    const dvGroups = fgOrder.map(([si, title]) => ({ title, items: DATA[si].items.map(s => {
      const i = s.pts.findIndex(p => p.d === selD); if (i < 0) return null;
      const p = s.pts[i], pr = i > 0 ? s.pts[i - 1] : null, st = status(p.v, s);
      dvN++; if (s.lo != null) { if (st === 'hi') dvHi++; else if (st === 'lo') dvLo++; else dvOk++; }
      const dv = pr ? Math.round((p.v - pr.v) * 100) / 100 : null;
      return { name: s.name, abbr: s.abbr, unit: s.unit, range: s.lo != null ? `${s.lo}–${s.hi}` : '–', val: fmt(p.v), bg: tint[st][0], fg: tint[st][1], mark: tint[st][2],
        delta: pr ? `${md(pr.d)} ${fmt(pr.v)} ${dv > 0 ? '▲' : dv < 0 ? '▼' : '='}${dv ? fmt(Math.abs(dv)) : ''}` : '첫 검사' };
    }).filter(Boolean) })).filter(g => g.items.length);
    const dvTouchStart = e => { const t = e.touches[0]; this._dvT = { x: t.clientX, y: t.clientY }; };
    const dvTouchEnd = e => { const s0 = this._dvT; this._dvT = null; if (!s0) return; const t = e.changedTouches[0]; const dx = t.clientX - s0.x, dy = t.clientY - s0.y; if (Math.abs(dx) < 50 || Math.abs(dx) < Math.abs(dy) * 1.5) return; if (dx < 0 && di < allD.length - 1) goD(allD[di + 1]); else if (dx > 0 && di > 0) goD(allD[di - 1]); };
    const dvVals = { dvTouchStart, dvTouchEnd, dvDates, dvGroups, dvHi, dvLo, dvOk, dvScrollRef: this.dvDragRef, chipDragRef: this.chipDragRef,
      dvTitle: `2026.${md(selD)} · ${selD === '05-05' ? '비엔·부평' : HS[DMAP[selD] || 'P']} · ${dvN}개 항목`,
      dvOlder: () => di < allD.length - 1 && goD(allD[di + 1]), dvNewer: () => di > 0 && goD(allD[di - 1]),
      dvOlderFg: di < allD.length - 1 ? '#4A3A33' : '#EBCFC4', dvNewerFg: di > 0 ? '#4A3A33' : '#EBCFC4' };
    const firstD = allD[allD.length - 1];
    const bwS = DATA.flatMap(sec => sec.items).find(s => s.abbr === 'BW'); const bwL = bwS && bwS.pts.length ? bwS.pts[bwS.pts.length - 1] : null;
    return { ...dvVals, hdrWeight: bwL ? `${fmt(bwL.v)} kg · ${md(bwL.d)}` : '–', mRange: firstD ? `${md(firstD)} – ${md(allD[0])}` : '', mJust: this.state.mJust || '', mHasJust: !!this.state.mJust, mJustClose: () => this.setState({ mJust: null }), mFlagGroups, mFlags, mHasFlags: mFlags.length > 0, mNoFlags: !mFlags.length, mFlagCount: mFlags.length, mWindow: fromD && fromD !== ld ? `${md(fromD)} – ${md(ld)}` : md(ld || ''), mLatest: ld ? `${md(ld)} · ${HS[DMAP[ld] || 'P']}` : '', mHi: hi, mLo: lo, mOk: ok, mPickHi: pick('hi'), mPickLo: pick('lo'), mPickAll: () => this.setState({ mFilter: 'all', mOpen: null }), mChips, mGroups,
      tblShow: !this.state.mob, mTblText: this.state.mTbl ? '날짜별 수치표 접기' : '날짜별 수치표 전체 보기', mTblToggle: () => this.setState(s => ({ mTbl: !s.mTbl }), () => this._bind && this._bind()) };
  }
  dvScrollRef = React.createRef();
  chipToLeft(el, b) {
    const pad = parseFloat(getComputedStyle(el).paddingLeft) || 0;
    const er = el.getBoundingClientRect(), br = b.getBoundingClientRect();
    const target = Math.max(0, Math.min(el.scrollWidth - el.clientWidth, el.scrollLeft + (br.left - er.left) - pad));
    const snap = el.style.scrollSnapType; el.style.scrollSnapType = 'none';
    el.scrollTo({ left: target, behavior: 'smooth' });
    clearTimeout(el._snapT); el._snapT = setTimeout(() => { el.style.scrollSnapType = snap; }, 500);
  }
  attachDrag(el) {
    if (el) this._chipEl = el; if (!el || el._drag) return; el._drag = true;
    let st = null, moved = false;
    el.style.cursor = 'grab';
    el.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse' || e.button !== 0) return; st = { x: e.clientX, l: el.scrollLeft, snap: el.style.scrollSnapType }; moved = false; });
    window.addEventListener('pointermove', e => { if (!st) return; const dx = e.clientX - st.x; if (!moved && Math.abs(dx) > 4) { moved = true; el.style.scrollSnapType = 'none'; el.style.cursor = 'grabbing'; document.body.style.userSelect = 'none'; } if (moved) el.scrollLeft = st.l - dx; });
    window.addEventListener('pointerup', () => { if (!st) return; el.style.scrollSnapType = st.snap; el.style.cursor = 'grab'; document.body.style.userSelect = ''; st = null; if (moved) setTimeout(() => { moved = false; }, 0); });
    el.addEventListener('click', e => { if (moved) { e.stopPropagation(); e.preventDefault(); return; } const b = e.target.closest('button'); if (b && b.parentElement === el) this.chipToLeft(el, b); }, true);
    el.addEventListener('dragstart', e => e.preventDefault());
  }
  dvDragRef = el => { this.dvScrollRef.current = el; this.attachDrag(el); };
  chipDragRef = el => { this._mChipEl = el; return this.attachDrag(el); };
  componentDidUpdate() {
    this._afterUpdate && this._afterUpdate();
    const cur = this.state && this.state.mDate;
    if (this._lastMDate !== cur) { this._lastMDate = cur; const el = this.dvScrollRef.current; const b = el && [...el.children].find(c => c.style.background === 'rgb(74, 58, 51)' || c.style.background === '#4A3A33'); if (b) this.chipToLeft(el, b); }
  }
  topScrollRef = React.createRef();
  topInnerRef = React.createRef();
  tableScrollRef = React.createRef();
  componentDidMount() {
    try { const av = localStorage.getItem('sungi-avatar'); if (av && this.avRef.current) this.avRef.current.src = av; } catch (e) {}
    { let done = false; const kill = () => document.querySelectorAll('#sg-splash').forEach(n => n.remove()); const hide = () => { if (done) return; done = true; document.querySelectorAll('#sg-splash').forEach(n => n.classList.add('out')); setTimeout(kill, 550); const go = () => { if (this._xr) return; this._xr = true; window.removeEventListener('scroll', go, true); (window.requestIdleCallback || (f => setTimeout(f, 50)))(() => this.setState({ xReady: true })); }; window.addEventListener('scroll', go, { capture: true, passive: true, once: true }); setTimeout(go, 2500); }; const idle = cb => (window.requestIdleCallback ? requestIdleCallback(cb, { timeout: 600 }) : setTimeout(cb, 150)); const sheets = [...document.querySelectorAll('link[rel="stylesheet"][href*="fonts.googleapis"]')].map(l => l.sheet ? Promise.resolve() : new Promise(r => { l.addEventListener('load', r, { once: true }); l.addEventListener('error', r, { once: true }); })); (document.fonts ? document.fonts.load('16px Cafe24Ssurround').catch(() => {}) : Promise.resolve()).then(() => setTimeout(() => idle(hide), 60)); setTimeout(() => { hide(); }, 1200); setTimeout(kill, 1800); document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { hide(); kill(); } }); }
    this._onScrollTop = () => { const y = Math.max(window.scrollY || 0, document.body.scrollTop || 0, document.documentElement.scrollTop || 0); const v = y > 400; if (v !== !!this.state.showTop) this.setState({ showTop: v }); };
    document.addEventListener('scroll', this._onScrollTop, { capture: true, passive: true });
    if (typeof matchMedia === 'function') { this._mq = matchMedia('(max-width: 640px)'); this._mqFn = () => {}; this._mq.addEventListener ? this._mq.addEventListener('change', this._mqFn) : this._mq.addListener(this._mqFn); }
    this.mountGallery();
    this._reloadLabs = () => { let list = []; try { list = JSON.parse(localStorage.getItem(LAB_KEY) || '[]') || []; } catch (e) { return; } if (JSON.stringify(list) === JSON.stringify(this.state.labs)) return; applyUserLabs(list); const ld = list.length ? list[list.length - 1].d : null; this.setState({ labs: list, mDate: ld || this.state.mDate, mJust: ld ? `${md(ld)} 검사 자료가 업데이트됨` : null }); };
    this._onStorage = e => { if (!e.key || e.key === LAB_KEY) this._reloadLabs(); if (!e.key || e.key === MEMO_KEY) { try { this.setState({ memos: JSON.parse(localStorage.getItem(MEMO_KEY) || '[]') || [] }); } catch (x) {} } };
    this._onVis = () => { if (document.visibilityState === 'visible') this._reloadLabs(); };
    window.addEventListener('storage', this._onStorage); document.addEventListener('visibilitychange', this._onVis); window.addEventListener('focus', this._onVis);
    window.__sungiDirty = () => { if (!this._fh) return; clearTimeout(this._bkT); this._bkT = setTimeout(async () => { try { const w = await this._fh.createWritable(); await w.write(await BK.build()); await w.close(); this.setState(s => ({ bk: { ...(s.bk || {}), msg: `${hhmm()} 저장됨` } })); } catch (e) { this.setState(s => ({ bk: { ...(s.bk || {}), msg: '자동 저장 실패' } })); } }, 800); };
    idb.get('__fs-handle').then(h => { if (h && h.queryPermission) h.queryPermission({ mode: 'readwrite' }).then(p => { if (p === 'granted') { this._fh = h; this.setState({ bk: { linked: true, name: h.name, msg: '연결됨' } }); } else { this._fhPending = h; this.forceUpdate(); } }); }).catch(() => {});
    const sync = () => {
      const top = this.topScrollRef.current, tbl = this.tableScrollRef.current, inner = this.topInnerRef.current;
      if (!top || !tbl || !inner) return false;
      if (top._dcBound) return true;
      top._dcBound = true;
      this._ro && this._ro.disconnect();
      const size = () => { inner.style.width = tbl.scrollWidth + 'px'; };
      size();
      this._ro = new ResizeObserver(size); this._ro.observe(tbl); if (tbl.firstElementChild) this._ro.observe(tbl.firstElementChild);
      top.addEventListener('scroll', () => { if (Math.abs(tbl.scrollLeft - top.scrollLeft) > 1) tbl.scrollLeft = top.scrollLeft; }, { passive: true });
      tbl.addEventListener('scroll', () => { if (Math.abs(top.scrollLeft - tbl.scrollLeft) > 1) top.scrollLeft = tbl.scrollLeft; }, { passive: true });
      return true;
    };
    this._bind = () => { if (!sync()) { clearInterval(this._syncT); this._syncT = setInterval(() => { if (sync()) clearInterval(this._syncT); }, 200); } };
    this._bind();
  }
  componentWillUnmount() { window.removeEventListener('storage', this._onStorage); document.removeEventListener('visibilitychange', this._onVis); window.removeEventListener('focus', this._onVis); if (this._mq) { this._mq.removeEventListener ? this._mq.removeEventListener('change', this._mqFn) : this._mq.removeListener(this._mqFn); } this.unmountGallery(); clearTimeout(this._bkT); if (window.__sungiDirty) window.__sungiDirty = null; clearInterval(this._syncT); this._ro && this._ro.disconnect(); }
  avRef = React.createRef();
  onAvatar = e => { const f = e.target.files && e.target.files[0]; e.target.value = ''; if (!f) return; const url = URL.createObjectURL(f); const im = new Image(); im.onload = () => { const S = 360, c = document.createElement('canvas'); c.width = c.height = S; const s = Math.min(im.width, im.height); c.getContext('2d').drawImage(im, (im.width - s) / 2, (im.height - s) / 2, s, s, 0, 0, S, S); URL.revokeObjectURL(url); const d = c.toDataURL('image/jpeg', 0.85); try { localStorage.setItem('sungi-avatar', d); } catch (err) {} if (this.avRef.current) this.avRef.current.src = d; }; im.src = url; };
  visitVals() {
    const KEY = 'sungi-visits-v1';
    if (!this._vs) { try { const r = localStorage.getItem(KEY); this._vs = r ? JSON.parse(r) : [{ id: 'v1104', iso: '2026-11-04', time: '19:00', memo: '' }]; if (!r) localStorage.setItem(KEY, JSON.stringify(this._vs)); } catch (e) { this._vs = []; } }
    const list = this.state.vs || this._vs;
    const save = l => { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch (e) {} this._vs = l; this.setState({ vs: l }); };
    const WD = ['일', '월', '화', '수', '목', '금', '토'];
    const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const info = v => { const [y, m, d] = v.iso.split('-').map(Number); const dt = new Date(y, m - 1, d); const diff = Math.round((dt - today) / 864e5);
      let tt = ''; if (v.time) { const [h, mi] = v.time.split(':').map(Number); tt = `${h < 12 ? '오전' : '오후'} ${h % 12 || 12}시${mi ? ' ' + mi + '분' : ''}`; }
      return { md: `${m}.${String(d).padStart(2, '0')}`, full: `${m}월 ${d}일 (${WD[dt.getDay()]})${tt ? ' ' + tt : ''}`, dday: diff === 0 ? '오늘' : diff > 0 ? `D-${diff}` : `D+${-diff}`, past: diff < 0, diff }; };
    const sorted = [...list].filter(v => v && v.iso).sort((a, b) => (a.iso + (a.time || '')).localeCompare(b.iso + (b.time || '')));
    const next = sorted.find(v => !info(v).past);
    const f = this.state.vsForm;
    const setF = o => this.setState(s => ({ vsForm: { ...s.vsForm, ...o, err: '' } }));
    const showAll = !!this.state.vsAll;
    const shown = sorted.filter(v => v !== next && (showAll || !info(v).past));
    return {
      vsSheet: !!this.state.vsSheet, vsOpenSheet: () => this.setState({ vsSheet: true }), vsCloseSheet: () => this.setState({ vsSheet: false, vsForm: null }), vsStop: e => e.stopPropagation(),
      vsHasNext: !!next, vsNoNext: !next,
      vsNext: next ? { ...info(next), memo: next.memo || '메모 없음' } : { md: '', full: '', dday: '', memo: '' },
      vsToggle: () => this.setState({ vsForm: f ? null : { iso: '', time: '', memo: '', id: null } }), vsToggleText: f ? '닫기' : '+ 일정 추가',
      vsFormOpen: !!f, vsFDate: f ? f.iso : '', vsFTime: f ? f.time : '', vsFMemo: f ? f.memo : '',
      vsOnDate: e => setF({ iso: e.target.value }), vsOnTime: e => setF({ time: e.target.value }), vsOnMemo: e => setF({ memo: e.target.value }),
      vsCancel: () => this.setState({ vsForm: null }), vsSubmitText: f && f.id ? '수정 저장' : '추가',
      vsHasErr: !!(f && f.err), vsErr: f ? f.err || '' : '',
      vsSubmit: () => { if (!f.iso) { this.setState({ vsForm: { ...f, err: '날짜를 골라주세요.' } }); return; } const item = { id: f.id || 'v' + Date.now().toString(36), iso: f.iso, time: f.time || '', memo: (f.memo || '').trim() }; save(f.id ? list.map(v => v.id === f.id ? item : v) : [...list, item]); this.setState({ vsForm: null }); },
      vsHasList: !!next || shown.length > 0,
      vsList: [
        ...(next ? [next] : []).concat(shown).map(v => { const i = info(v); return { full: i.full, sub: [i.dday, v.memo].filter(Boolean).join(' · '), op: i.past ? '0.55' : '1',
          edit: () => this.setState({ vsForm: { id: v.id, iso: v.iso, time: v.time || '', memo: v.memo || '' } }),
          del: () => { if (!window.confirm(`${i.full} 일정을 삭제할까요?`)) return; save(list.filter(x => x.id !== v.id)); } }; }),
      ],
      vsPastBtn: sorted.some(v => info(v).past), vsPastText: showAll ? '지난 일정 숨기기' : '지난 일정 보기', vsPastToggle: () => this.setState(s => ({ vsAll: !s.vsAll })),
    };
  }
  renderVals() { return { ...this.renderVals0(), ...this.visitVals(), avRef: this.avRef, onAvatar: this.onAvatar }; }
  renderVals0() {
    const showBand = this.props.showBand ?? true;
    const byHosp = (this.props.pointColor ?? '수치 상태') === '병원별';
    const sections = DATA.map(sec => ({
      title: sec.title, sub: sec.sub,
      items: sec.items.map(s => {
        const last = s.pts[s.pts.length - 1];
        let a = s.pts[0], b = s.pts[0];
        s.pts.forEach(p => { if (p.v > a.v) a = p; if (p.v < b.v) b = p; });
        return {
          name: s.name, abbr: s.abbr, unit: s.unit,
          rangeText: s.lo != null ? `${s.lo} – ${s.hi}` : '–',
          latest: fmt(last.v), latestDate: md(last.d), latestColor: C[status(last.v, s)],
          maxText: `${fmt(a.v)} (${md(a.d)})`, minText: `${fmt(b.v)} (${md(b.d)})`, count: s.pts.length,
          chart: React.createElement(Chart, { s, showBand, byHosp }),
        };
      }),
    }));
    const all = [...new Set(DATA.flatMap(sec => sec.items.flatMap(s => s.pts.map(p => p.d))))].sort();
    const HS = { S: '심장', J: '지중해', B: '비엔', P: '부평' };
    let pm = '';
    const dates = [...all].reverse().map(d => {
      const m = +d.split('-')[0];
      const ml = m + '' !== pm ? m + '월' : ''; pm = m + '';
      return { d, day: +d.split('-')[1], month: ml, hosp: d === '05-05' ? '비엔·부평' : HS[DMAP[d] || 'P'], border: ml ? '1px solid #EBCFC4' : '1px solid transparent' };
    });
    const cellStyle = (v, s) => {
      const st = status(v, s);
      if (st === 'ok') return { bg: 'transparent', fg: '#4A3A33', mark: '' };
      const span = (s.hi - s.lo) || 1;
      const dev = st === 'hi' ? (v - s.hi) / span : (s.lo - v) / span;
      const strong = dev > 0.5;
      return st === 'hi'
        ? { bg: strong ? 'oklch(0.86 0.09 28)' : 'oklch(0.94 0.04 28)', fg: 'oklch(0.42 0.16 28)', mark: '↑' }
        : { bg: strong ? 'oklch(0.86 0.07 250)' : 'oklch(0.94 0.03 250)', fg: 'oklch(0.40 0.14 250)', mark: '↓' };
    };
    const groups = DATA.map(sec => ({
      title: sec.title,
      rows: sec.items.map(s => {
        const byD = {}; s.pts.forEach(p => { byD[p.d] = p; });
        return {
          abbr: s.abbr, name: s.name, unit: s.unit, range: s.lo != null ? `${s.lo}–${s.hi}` : '',
          cells: dates.map(dt => {
            const p = byD[dt.d];
            if (!p) return { text: '·', bg: 'transparent', fg: '#EBCFC4', mark: '', border: dt.border, tip: '' };
            const cs = cellStyle(p.v, s);
            return { text: fmt(p.v), ...cs, border: dt.border, tip: `${s.abbr} ${fmt(p.v)} ${s.unit} · 2026.${md(p.d)} · ${HOSP[p.h]}` };
          }),
        };
      }),
    }));
    const tab = this.state.tab;
    const tabs = [['labs', '검사', '🩺'], ['meds', '투약', '💊'], ['diet', '식단', '🍚'], ['kcal', '칼로리', '🔥'], ['memo', '메모', '📝'], ['check', '체크', '✅']].map(([k, label, icon]) => ({ label, icon, bg: tab === k ? '#FFDCE3' : 'transparent', line: 'transparent', fg: tab === k ? '#E0607A' : '#B59C92', onClick: () => this.setState({ tab: k }) }));
    return { isMob: !!this.state.mob, notMob: !this.state.mob, topBarDisplay: this.state.mob ? 'none' : 'block', tabs, tabsL: tabs.slice(0, 3), tabsR: tabs.slice(3),
      navAdd: () => this.openLabSheet(), showTop: !!this.state.showTop, goTop: () => { try { document.body.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { document.body.scrollTop = 0; } try { document.documentElement.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) {} window.scrollTo({ top: 0, behavior: 'smooth' }); }, ...this.mobVals(), ...this.memoVals(), isLabs: tab === 'labs', isMemo: tab === 'memo', isCheck: tab === 'check', ...this.checkVals(), isMeds: tab === 'meds', isDiet: tab === 'diet', isKcal: tab === 'kcal', ...this.bkVals(), ...this.exportVals(), ...this.kcalVals(), ...this.labVals(), ...this.dietVals(), ...this.medVals(), sections, dates, groups, topScrollRef: this.topScrollRef, topInnerRef: this.topInnerRef, tableScrollRef: this.tableScrollRef, ...this.galleryVals(), ...this.xrayVals() };
  }
}

;return (typeof Component!=="undefined"&&Component)||undefined;};
